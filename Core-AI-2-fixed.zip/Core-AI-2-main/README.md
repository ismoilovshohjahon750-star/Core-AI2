# Core AI

Oʻzbek tilida ishlaydigan chat yordamchi (Next.js 15 + React 19 + Tailwind 4 + Gemini / OpenRouter).

## Ishga tushirish

```bash
bun install        # yoki: npm install
cp .env.example .env.local   # GEMINI_API_KEY ni kiriting
bun run dev        # http://localhost:3000
```

Boshqa buyruqlar: `bun run build`, `bun run lint`, `bun run typecheck`, `bun run test`.

## Sozlamalar (`.env.local`)

| Oʻzgaruvchi | Vazifasi |
| --- | --- |
| `GEMINI_API_KEY` | Majburiy (Gemini modellari va ovoz uchun). Kalitsiz chat aniq xato xabarini koʻrsatadi. |
| `GEMINI_MODEL` | Ixtiyoriy. Foydalanuvchi Sozlamalarda model tanlamagan boʻlsa ishlatiladi. Standart: `gemini-3.8-flash`. |
| `GEMINI_TTS_MODEL` | Ixtiyoriy. Ovoz chiqarib oʻqish modeli. Standart: `gemini-3.8-flash-lite-tts`. |
| `OPENROUTER_API_KEY` | Ixtiyoriy. Faqat OpenRouter modellari (DeepSeek, Llama, GPT, Claude...) uchun. |
| `NEXT_PUBLIC_USER_NAME` | Yon paneldagi profil nomi. |

## Modellar haqida

Model roʻyxati `lib/model-config.ts` da. Google `gemini-2.0-*` va `gemini-1.5-*` modellarini oʻchirgan, `gemini-2.5-*` esa
yangi loyihalar uchun cheklangan, shuning uchun standart model `gemini-3.8-flash`. Roʻyxatni yangilashdan oldin
[Gemini deprecations](https://ai.google.dev/gemini-api/docs/deprecations) sahifasini tekshiring.

## Tuzilma

- `app/api/chat/route.ts` — Gemini va OpenRouter bilan oqimli (streaming) aloqa
- `app/api/tts/route.ts` — Gemini TTS (xom PCM audio WAV ga oʻraladi, `lib/audio-utils.ts`)
- `lib/gemini.ts`, `lib/openrouter.ts` — tarixni model formatiga oʻtkazish (testlangan)
- `lib/conversation-store.ts` — suhbatlar xotirasi (localStorage, kvota himoyasi bilan)
- `hooks/use-chat.ts` — yuborish, toʻxtatish, qayta yaratish mantiqi
- `app/globals.css` — dizayn tokenlari (yorugʻ/qorongʻi mavzu)
- `components/*` — interfeys komponentlari
