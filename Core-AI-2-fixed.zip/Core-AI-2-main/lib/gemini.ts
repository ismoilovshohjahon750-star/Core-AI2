import type { Content, Part } from '@google/genai';

export interface IncomingAttachment {
  id?: string;
  name: string;
  type: string;
  size?: number;
  dataUrl?: string;
  textContent?: string;
  rawBase64?: string;
}

export interface IncomingMessage {
  role: string;
  content?: string;
  error?: boolean;
  attachments?: IncomingAttachment[];
}

export const MAX_HISTORY_MESSAGES = 30;
/** Faqat oxirgi N ta foydalanuvchi xabaridagi fayllar toʻliq yuboriladi (token va hajmni tejash uchun). */
export const FULL_ATTACHMENT_TURNS = 2;
export const ALLOWED_INLINE_MIME = ['image/png', 'image/jpeg', 'image/webp', 'application/pdf'];
const DEFAULT_FILE_PROMPT = "Ushbu biriktirilgan fayl mazmunini tahlil qiling va u boʻyicha toʻliq maʼlumot bering.";

/** Matn ichida ``` uchrasa ham toʻsiq buzilmasligi uchun yetarli uzunlikdagi backtick qatorini qaytaradi. */
export function fenceFor(text: string): string {
  let longest = 0;
  for (const match of text.matchAll(/`+/g)) longest = Math.max(longest, match[0].length);
  return '`'.repeat(Math.max(3, longest + 1));
}

export function textAttachmentToPrompt(name: string, textContent: string): string {
  const fence = fenceFor(textContent);
  return `[Biriktirilgan fayl: ${name}]\n${fence}\n${textContent}\n${fence}`;
}

export function parseDataUrl(dataUrl: string): { mimeType: string; data: string } | null {
  if (!dataUrl.startsWith('data:')) return null;
  const comma = dataUrl.indexOf(',');
  if (comma < 0) return null;
  const meta = dataUrl.slice(5, comma);
  if (!meta.includes(';base64')) return null;
  const mimeType = meta.split(';')[0];
  const data = dataUrl.slice(comma + 1);
  return mimeType && data ? { mimeType, data } : null;
}

function attachmentToPart(att: IncomingAttachment): Part | null {
  if (att.textContent) {
    return { text: textAttachmentToPrompt(att.name, att.textContent) };
  }
  let mimeType = att.type;
  let data: string | undefined = att.rawBase64;
  if (att.dataUrl) {
    const parsed = parseDataUrl(att.dataUrl);
    if (parsed) {
      mimeType = parsed.mimeType;
      data = parsed.data;
    }
  }
  if (data && ALLOWED_INLINE_MIME.includes(mimeType)) {
    return { inlineData: { mimeType, data } };
  }
  return null;
}

/**
 * Suhbat tarixini Gemini `contents` formatiga oʻtkazadi:
 * navbatma-navbat user/model, birinchisi doim user, oxirgisi user.
 * Boʻsh qolgan yoki xato xabarlar tashlab yuboriladi.
 */
export function toGeminiContents(messages: IncomingMessage[]): Content[] {
  const recent = messages.slice(-MAX_HISTORY_MESSAGES).filter((m) => !m.error);

  const userIndexes = recent.map((m, i) => (m.role === 'user' ? i : -1)).filter((i) => i >= 0);
  const fullFrom = new Set(userIndexes.slice(-FULL_ATTACHMENT_TURNS));

  const raw: Content[] = [];
  recent.forEach((m, i) => {
    const text = m.content?.trim() ?? '';
    if (m.role === 'user') {
      const parts: Part[] = [];
      for (const att of m.attachments ?? []) {
        if (fullFrom.has(i)) {
          const part = attachmentToPart(att);
          if (part) parts.push(part);
        } else {
          parts.push({ text: `[Avval biriktirilgan fayl: ${att.name}]` });
        }
      }
      if (text) parts.push({ text });
      else if (parts.length > 0) parts.push({ text: DEFAULT_FILE_PROMPT });
      if (parts.length > 0) raw.push({ role: 'user', parts });
    } else if (m.role === 'assistant' && text) {
      raw.push({ role: 'model', parts: [{ text }] });
    }
  });

  const merged: Content[] = [];
  for (const item of raw) {
    const last = merged[merged.length - 1];
    if (last && last.role === item.role) {
      last.parts = [...(last.parts ?? []), ...(item.parts ?? [])];
    } else {
      merged.push({ role: item.role, parts: [...(item.parts ?? [])] });
    }
  }

  while (merged.length > 0 && merged[0].role !== 'user') merged.shift();
  while (merged.length > 0 && merged[merged.length - 1].role !== 'user') merged.pop();
  return merged;
}

export function buildSystemInstruction(now = new Date()): string {
  const date = now.toISOString().slice(0, 10);
  return [
    `Siz Core AI — aqlli, aniq va muloyim professional yordamchisiz. Bugungi sana: ${date}.`,
    'Qatʼiy qoidalar:',
    '1. Hech qachon EMOJI ishlatmang.',
    '2. Foydalanuvchi qaysi tilda yozsa, oʻsha tilda javob bering. Til noaniq boʻlsa — oʻzbek tilida (lotin yozuvi), imloviy jihatdan toʻgʻri va ravon yozing.',
    '3. Rasm yoki fayl yuborilgan boʻlsa, uni sinchiklab tahlil qiling: obyektlar, yozuvlar, kod, diagramma yoki hujjat maʼlumotlarini aniq tushuntiring.',
    '4. Kod soʻralsa yoki tekshirilsa — toʻgʻri sintaksis, toza tuzilma va zarur izohlar bilan, til nomi koʻrsatilgan kod bloklarida bering.',
    '5. Javoblarni markdown bilan tartiblang (sarlavha, roʻyxat, jadval, kod bloki), lekin keraksiz uzaytirmang.',
    "6. Bilmagan narsangizni uydirmang; ishonchingiz komil boʻlmasa, shuni ochiq ayting.",
  ].join('\n');
}

export function describeGeminiError(error: unknown): { status: number; message: string } {
  const status =
    typeof error === 'object' && error !== null && 'status' in error && typeof (error as { status: unknown }).status === 'number'
      ? (error as { status: number }).status
      : 0;

  if (status === 400) return { status: 400, message: "So'rov Gemini tomonidan qabul qilinmadi. Fayl formati yoki hajmini tekshiring." };
  if (status === 401 || status === 403) return { status: 502, message: 'GEMINI_API_KEY yaroqsiz yoki ruxsati yoʻq. Kalitni tekshiring.' };
  if (status === 404) {
    return {
      status: 502,
      message: 'Tanlangan model topilmadi yoki sizning kalitingiz uchun yopilgan. Sozlamalardan boshqa modelni tanlang.',
    };
  }
  if (status === 429) return { status: 429, message: "So'rovlar limiti oshib ketdi. Birozdan keyin qayta urinib koʻring." };
  if (status >= 500) return { status: 502, message: 'Gemini xizmati vaqtincha ishlamayapti. Birozdan keyin qayta urinib koʻring.' };
  return { status: 502, message: 'Javob olishda xatolik yuz berdi. Qayta urinib koʻring.' };
}
