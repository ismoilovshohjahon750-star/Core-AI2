export interface ChatAttachment {
  id: string;
  name: string;
  type: string;
  size: number;
  /** Rasm va PDF uchun `data:` URL (oldindan koʻrish, yuklab olish va API uchun). */
  dataUrl?: string;
  /** Matnli fayllar mazmuni. */
  textContent?: string;
  /** @deprecated Eski versiyalardan qolgan; endi `dataUrl` ishlatiladi. */
  rawBase64?: string;
}

export interface ChatMessageItem {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  liked?: boolean;
  disliked?: boolean;
  /** Xato xabari — tarixga (API ga) yuborilmaydi. */
  error?: boolean;
  attachments?: ChatAttachment[];
}

export type ConversationCategory = 'BUGUN' | 'KECHA' | 'OLDINGI';

export interface Conversation {
  id: string;
  title: string;
  snippet: string;
  updatedAt: number;
  messages: ChatMessageItem[];
}

export interface MediaItem {
  id: string;
  attachment: ChatAttachment;
  conversationId: string;
  conversationTitle: string;
  timestamp: number;
  role: 'user' | 'assistant';
}
