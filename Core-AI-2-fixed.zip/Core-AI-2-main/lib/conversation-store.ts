'use client';

import { useSyncExternalStore } from 'react';
import type { ChatAttachment, Conversation } from './types';

const STORAGE_KEY = 'core_ai_conversations_v1';
const LEGACY_KEYS = ['umida_ai_conversations_v1', 'umida_ai_conversations_v2'];
const PERSIST_DELAY_MS = 400;

type Updater = Conversation[] | ((prev: Conversation[]) => Conversation[]);

let memory: Conversation[] = [];
let initialized = false;
let persistTimer: ReturnType<typeof setTimeout> | null = null;
const listeners = new Set<() => void>();

function notify() {
  listeners.forEach((l) => l());
}

function sanitize(raw: unknown): Conversation[] {
  if (!Array.isArray(raw)) return [];
  const result: Conversation[] = [];
  for (const c of raw) {
    if (!c || typeof c.id !== 'string' || !Array.isArray(c.messages) || c.messages.length === 0) continue;
    result.push({
      id: c.id,
      title: typeof c.title === 'string' ? c.title : 'Yangi suhbat',
      snippet: typeof c.snippet === 'string' ? c.snippet : '',
      updatedAt: typeof c.updatedAt === 'number' ? c.updatedAt : Date.now(),
      messages: c.messages
        .filter((m: { role?: string }) => m && (m.role === 'user' || m.role === 'assistant'))
        .map((m: Conversation['messages'][number]) => ({
          ...m,
          attachments: m.attachments?.map((a: ChatAttachment) => {
            const { rawBase64, ...rest } = a;
            // Eski yozuvlarda rawBase64 dataUrl bilan takrorlanib xotirani ikki barobar band qilgan.
            return rest.dataUrl || !rawBase64 ? rest : { ...rest, dataUrl: `data:${a.type};base64,${rawBase64}` };
          }),
        })),
    });
  }
  return result;
}

function load() {
  try {
    LEGACY_KEYS.forEach((k) => localStorage.removeItem(k));
    const saved = localStorage.getItem(STORAGE_KEY);
    memory = saved ? sanitize(JSON.parse(saved)) : [];
  } catch {
    memory = [];
  }
}

function slim(conversations: Conversation[], mode: 'non-images' | 'all'): Conversation[] {
  return conversations.map((c) => ({
    ...c,
    messages: c.messages.map((m) => ({
      ...m,
      attachments: m.attachments?.map((a) => {
        const keep = mode === 'non-images' && a.type.startsWith('image/');
        return keep ? a : { ...a, dataUrl: undefined };
      }),
    })),
  }));
}

function persistNow() {
  if (persistTimer) {
    clearTimeout(persistTimer);
    persistTimer = null;
  }
  if (typeof window === 'undefined') return;
  // Xotira toʻlib qolsa (quota), avval PDF lar, soʻng barcha rasmlar saqlanmaydi — suhbat matni baribir saqlanadi.
  for (const candidate of [memory, slim(memory, 'non-images'), slim(memory, 'all')]) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(candidate));
      return;
    } catch {
      // keyingi variantga oʻtamiz
    }
  }
}

function schedulePersist() {
  if (persistTimer) clearTimeout(persistTimer);
  persistTimer = setTimeout(persistNow, PERSIST_DELAY_MS);
}

function init() {
  if (initialized || typeof window === 'undefined') return;
  initialized = true;
  load();
  window.addEventListener('pagehide', persistNow);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') persistNow();
  });
  window.addEventListener('storage', (e) => {
    if (e.key === STORAGE_KEY) {
      load();
      notify();
    }
  });
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function getSnapshot(): Conversation[] {
  init();
  return memory;
}

const SERVER_SNAPSHOT: Conversation[] = [];
const getServerSnapshot = () => SERVER_SNAPSHOT;

function updateConversations(updater: Updater) {
  init();
  memory = typeof updater === 'function' ? updater(memory) : updater;
  schedulePersist();
  notify();
}

function clearAllConversations() {
  memory = [];
  if (typeof window !== 'undefined') {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  }
  if (persistTimer) {
    clearTimeout(persistTimer);
    persistTimer = null;
  }
  notify();
}

/** Hozircha kutilayotgan yozuvni darhol saqlaydi (masalan, javob yakunlanganda). */
export function flushConversations() {
  persistNow();
}

const noopSubscribe = () => () => {};

export function useConversations() {
  const conversations = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const hydrated = useSyncExternalStore(noopSubscribe, () => true, () => false);
  return { conversations, hydrated, update: updateConversations, clearAll: clearAllConversations };
}
