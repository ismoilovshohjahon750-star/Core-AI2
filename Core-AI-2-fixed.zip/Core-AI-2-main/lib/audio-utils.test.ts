import test from 'node:test';
import assert from 'node:assert/strict';
import { pcm16ToWav, toPlayableAudio } from './audio-utils.ts';

test('pcm16ToWav toʻgʻri RIFF/WAVE sarlavhasini yozadi', () => {
  const pcm = new Uint8Array([1, 0, 2, 0, 3, 0, 4, 0]);
  const wav = pcm16ToWav(pcm, 24000, 1);
  const text = (from: number, to: number) => String.fromCharCode(...wav.slice(from, to));
  const view = new DataView(wav.buffer);

  assert.equal(wav.length, 44 + pcm.length);
  assert.equal(text(0, 4), 'RIFF');
  assert.equal(text(8, 12), 'WAVE');
  assert.equal(view.getUint32(24, true), 24000);
  assert.equal(view.getUint32(40, true), pcm.length);
  assert.deepEqual(Array.from(wav.slice(44)), Array.from(pcm));
});

test('toPlayableAudio xom PCM ni WAV ga oʻraydi, tayyor formatni oʻzgartirmaydi', () => {
  const b64 = Buffer.from([1, 0, 2, 0]).toString('base64');

  const pcm = toPlayableAudio(b64, 'audio/L16;codec=pcm;rate=24000');
  assert.equal(pcm.contentType, 'audio/wav');
  assert.equal(pcm.bytes.length, 48);

  const noMime = toPlayableAudio(b64, undefined);
  assert.equal(noMime.contentType, 'audio/wav');

  const mp3 = toPlayableAudio(b64, 'audio/mpeg');
  assert.equal(mp3.contentType, 'audio/mpeg');
  assert.equal(mp3.bytes.length, 4);
});
