import type { ChatAttachment } from './types.ts';

export const MAX_FILE_BYTES = 10 * 1024 * 1024;
export const MAX_TOTAL_BYTES = 12 * 1024 * 1024;
export const MAX_FILES = 5;
export const MAX_TEXT_CHARS = 200_000;

const IMAGE_MIME = ['image/png', 'image/jpeg', 'image/webp'];

const TEXT_EXTENSIONS = [
  'txt', 'md', 'json', 'csv', 'tsv', 'js', 'jsx', 'ts', 'tsx', 'py', 'html', 'css', 'sql', 'xml',
  'yml', 'yaml', 'sh', 'java', 'c', 'cpp', 'go', 'rs', 'php', 'rb', 'log',
];

/** `<input type="file" accept>` uchun. Gemini oʻqiy olmaydigan formatlar (DOCX, GIF, SVG) kiritilmagan. */
export const FILE_ACCEPT = [
  ...IMAGE_MIME,
  'application/pdf',
  ...TEXT_EXTENSIONS.map((e) => `.${e}`),
].join(',');

export type FileKind = 'image' | 'pdf' | 'text' | 'unsupported';

function extensionOf(name: string): string {
  const idx = name.lastIndexOf('.');
  return idx === -1 ? '' : name.slice(idx + 1).toLowerCase();
}

export function classifyFile(file: Pick<File, 'name' | 'type'>): FileKind {
  const ext = extensionOf(file.name);
  if (IMAGE_MIME.includes(file.type)) return 'image';
  if (file.type === 'application/pdf' || ext === 'pdf') return 'pdf';
  if (file.type.startsWith('text/') || TEXT_EXTENSIONS.includes(ext)) return 'text';
  if (ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'webp') return 'image';
  return 'unsupported';
}

function imageMimeFromName(name: string, fallback: string): string {
  const ext = extensionOf(name);
  if (ext === 'png') return 'image/png';
  if (ext === 'jpg' || ext === 'jpeg') return 'image/jpeg';
  if (ext === 'webp') return 'image/webp';
  return fallback || 'image/png';
}

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error ?? new Error('Faylni oʻqib boʻlmadi'));
    reader.readAsDataURL(file);
  });
}

function readAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error ?? new Error('Faylni oʻqib boʻlmadi'));
    reader.readAsText(file);
  });
}

function newId(): string {
  return `att-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export async function fileToAttachment(file: File, kind: Exclude<FileKind, 'unsupported'>): Promise<ChatAttachment> {
  if (kind === 'text') {
    let textContent = await readAsText(file);
    if (textContent.length > MAX_TEXT_CHARS) {
      textContent = textContent.slice(0, MAX_TEXT_CHARS) + '\n\n[... fayl uzunligi sababli qisqartirildi]';
    }
    return { id: newId(), name: file.name, type: file.type || 'text/plain', size: file.size, textContent };
  }

  const dataUrl = await readAsDataUrl(file);
  const type = kind === 'pdf' ? 'application/pdf' : imageMimeFromName(file.name, file.type);
  return { id: newId(), name: file.name, type, size: file.size, dataUrl };
}

/** Faylni brauzer orqali yuklab oladi (vaqtinchalik URL xotirasi tozalanadi). */
export function downloadAttachment(att: ChatAttachment): void {
  if (!att.dataUrl && !att.textContent) return;

  let objectUrl: string | null = null;
  const link = document.createElement('a');
  if (att.dataUrl) {
    link.href = att.dataUrl;
  } else {
    objectUrl = URL.createObjectURL(new Blob([att.textContent ?? ''], { type: att.type || 'text/plain' }));
    link.href = objectUrl;
  }
  link.download = att.name;
  document.body.appendChild(link);
  link.click();
  link.remove();
  if (objectUrl) {
    const url = objectUrl;
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}
