import test from 'node:test';
import assert from 'node:assert/strict';
import {
  AVAILABLE_MODELS,
  DEFAULT_MODEL_ID,
  isValidModelId,
  sanitizeModelId,
} from './model-config.ts';

test('AVAILABLE_MODELS joriy Gemini va OpenRouter modellarini oʻz ichiga oladi', () => {
  const ids = AVAILABLE_MODELS.map((m) => m.id);
  for (const id of [
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-3.1-pro-preview',
    'deepseek/deepseek-chat',
    'deepseek/deepseek-r1',
    'meta-llama/llama-3.3-70b-instruct',
    'qwen/qwen-2.5-72b-instruct',
    'openai/gpt-4o',
    'openai/gpt-4o-mini',
    'anthropic/claude-3.5-sonnet',
  ]) {
    assert.ok(ids.includes(id), `${id} roʻyxatda boʻlishi kerak`);
  }
  // Qatʼiy cheklov: gemini-4-argon roʻyxatda boʻlmasligi shart
  assert.ok(!ids.includes('gemini-4-argon'));
});

test('oʻchirilgan modellar (gemini-2.0-*, gemini-1.5-*) roʻyxatda yoʻq', () => {
  const ids = AVAILABLE_MODELS.map((m) => m.id);
  assert.ok(!ids.some((id) => id.startsWith('gemini-1.5') || id.startsWith('gemini-2.0')));
});

test('modellar identifikatorlari takrorlanmaydi va standart model roʻyxatda bor', () => {
  const ids = AVAILABLE_MODELS.map((m) => m.id);
  assert.equal(new Set(ids).size, ids.length);
  assert.ok(ids.includes(DEFAULT_MODEL_ID));
});

test('isValidModelId faqat ruxsat etilgan modellar uchun true qaytaradi', () => {
  assert.equal(isValidModelId('gemini-3.8-flash'), true);
  assert.equal(isValidModelId('deepseek/deepseek-chat'), true);
  assert.equal(isValidModelId('openai/gpt-4o'), true);

  assert.equal(isValidModelId('gemini-4-argon'), false);
  assert.equal(isValidModelId('gemini-2.0-flash'), false);
  assert.equal(isValidModelId('unapproved-custom-model'), false);
  assert.equal(isValidModelId(''), false);
  assert.equal(isValidModelId(null), false);
  assert.equal(isValidModelId(undefined), false);
});

test('sanitizeModelId notoʻgʻri yoki eskirgan modellar kelsa standartni qaytaradi', () => {
  assert.equal(sanitizeModelId('gemini-3.1-pro-preview'), 'gemini-3.1-pro-preview');
  assert.equal(sanitizeModelId('deepseek/deepseek-r1'), 'deepseek/deepseek-r1');
  assert.equal(sanitizeModelId('gemini-2.0-flash'), DEFAULT_MODEL_ID);
  assert.equal(sanitizeModelId('gemini-4-argon'), DEFAULT_MODEL_ID);
  assert.equal(sanitizeModelId(undefined), DEFAULT_MODEL_ID);
  assert.equal(sanitizeModelId(null), DEFAULT_MODEL_ID);
});
