import test from 'node:test';
import assert from 'node:assert/strict';
import { toOpenRouterMessages } from './openrouter.ts';

test('toOpenRouterMessages tizim xabarini boshiga qoʻyadi va xato xabarlarni tashlaydi', () => {
  const out = toOpenRouterMessages(
    [
      { role: 'user', content: 'Salom' },
      { role: 'assistant', content: 'Xato', error: true },
      { role: 'user', content: 'Qayta' },
    ],
    'SYS'
  );
  assert.equal(out[0].role, 'system');
  assert.deepEqual(out.slice(1).map((m) => m.role), ['user', 'user']);
});

test('toOpenRouterMessages matnli faylni xabarga qoʻshadi (avval jimgina tashlab yuborilar edi)', () => {
  const out = toOpenRouterMessages(
    [{ role: 'user', content: '', attachments: [{ name: 'a.py', type: 'text/plain', textContent: 'print(1)' }] }],
    'SYS'
  );
  const content = out[1].content;
  assert.equal(typeof content, 'string');
  assert.ok((content as string).includes('print(1)'));
  assert.ok((content as string).includes('a.py'));
});

test('toOpenRouterMessages rasmni image_url qismi sifatida yuboradi', () => {
  const out = toOpenRouterMessages(
    [
      {
        role: 'user',
        content: 'Bu nima?',
        attachments: [{ name: 'x.png', type: 'image/png', dataUrl: 'data:image/png;base64,QUJD' }],
      },
    ],
    'SYS'
  );
  const content = out[1].content;
  assert.ok(Array.isArray(content));
  assert.ok(content.some((p) => p.type === 'image_url'));
});

test('toOpenRouterMessages birinchi assistant xabarini olib tashlaydi', () => {
  const out = toOpenRouterMessages(
    [
      { role: 'assistant', content: 'Eski' },
      { role: 'user', content: 'Savol' },
    ],
    'SYS'
  );
  assert.deepEqual(out.map((m) => m.role), ['system', 'user']);
});
