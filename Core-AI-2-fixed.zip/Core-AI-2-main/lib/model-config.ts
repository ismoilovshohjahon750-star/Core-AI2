export type ModelProvider = 'gemini' | 'openrouter';
export type ModelIcon = 'sparkles' | 'zap' | 'cpu' | 'bot' | 'brain' | 'globe' | 'code';

export interface ModelDefinition {
  id: string;
  name: string;
  provider: ModelProvider;
  tag: string;
  description: string;
  speed: string;
  badge: string;
  icon: ModelIcon;
}

/**
 * Gemini API rasmiy hujjatlariga (deprecations, 2026-10) muvofiq yangilangan roʻyxat.
 * gemini-2.0-* va gemini-1.5-* modellari oʻchirilgan, shuning uchun roʻyxatdan olib tashlandi.
 * gemini-2.5-* modellari yangi loyihalar uchun cheklangan ("Eski" belgisi bilan qoldirildi).
 */
export const AVAILABLE_MODELS: readonly ModelDefinition[] = [
  // --- Gemini ---
  {
    id: 'gemini-3.8-flash',
    name: 'Gemini 3.8 Flash',
    provider: 'gemini',
    tag: 'Standart',
    description: 'Eng aqlli Flash modeli: kundalik savollar, kod va murakkab vazifalar uchun (Tavsiya etiladi).',
    speed: 'Tezkor',
    badge: 'Tavsiya etiladi',
    icon: 'sparkles',
  },
  {
    id: 'gemini-3.6-flash',
    name: 'Gemini 3.6 Flash',
    provider: 'gemini',
    tag: 'Muvozanatli',
    description: 'Tezlik va multimodal imkoniyatlar muvozanati: matn, rasm va hujjatlar tahlili.',
    speed: 'Tezkor',
    badge: 'Barqaror',
    icon: 'sparkles',
  },
  {
    id: 'gemini-3.5-flash-lite',
    name: 'Gemini 3.5 Flash-Lite',
    provider: 'gemini',
    tag: 'Yengil va tez',
    description: 'Oddiy savollar va ommaviy soʻrovlarga eng tez va tejamkor javob.',
    speed: 'Eng tezkor',
    badge: 'Tezkor',
    icon: 'zap',
  },
  {
    id: 'gemini-3.1-flash-lite',
    name: 'Gemini 3.1 Flash-Lite',
    provider: 'gemini',
    tag: 'Tejamkor',
    description: 'Yuqori samaradorlikdagi yengil model, kichik vazifalar uchun.',
    speed: 'Juda tezkor',
    badge: 'Yengil',
    icon: 'zap',
  },
  {
    id: 'gemini-3.1-pro-preview',
    name: 'Gemini 3.1 Pro (Preview)',
    provider: 'gemini',
    tag: 'Chuqur fikrlash',
    description: 'Murakkab masalalar, dasturlash va katta hajmli tahlillar uchun eng kuchli tanlov.',
    speed: 'Oʻrtacha',
    badge: 'Chuqur tahlil',
    icon: 'cpu',
  },
  {
    id: 'gemini-2.5-flash',
    name: 'Gemini 2.5 Flash',
    provider: 'gemini',
    tag: 'Eski avlod',
    description: 'Eski avlod modeli. Google uni faqat avval ishlatgan loyihalar uchun ochiq qoldirgan.',
    speed: 'Tezkor',
    badge: 'Eski',
    icon: 'sparkles',
  },
  {
    id: 'gemini-2.5-pro',
    name: 'Gemini 2.5 Pro',
    provider: 'gemini',
    tag: 'Eski avlod',
    description: 'Eski avlod chuqur fikrlash modeli. Yangi kalitlarda mavjud boʻlmasligi mumkin.',
    speed: 'Oʻrtacha',
    badge: 'Eski',
    icon: 'cpu',
  },

  // --- OpenRouter ---
  {
    id: 'deepseek/deepseek-chat',
    name: 'DeepSeek V3',
    provider: 'openrouter',
    tag: 'OpenRouter / DeepSeek',
    description: 'Kuchli va tezkor umumiy model.',
    speed: 'Tezkor',
    badge: 'OpenRouter',
    icon: 'bot',
  },
  {
    id: 'deepseek/deepseek-r1',
    name: 'DeepSeek R1',
    provider: 'openrouter',
    tag: 'OpenRouter / Reasoning',
    description: 'Matematika va mantiqiy masalalarni qadamma-qadam yechuvchi model.',
    speed: 'Mantiqiy',
    badge: 'OpenRouter',
    icon: 'brain',
  },
  {
    id: 'meta-llama/llama-3.3-70b-instruct',
    name: 'Llama 3.3 70B',
    provider: 'openrouter',
    tag: 'OpenRouter / Meta',
    description: 'Meta ochiq manbali 70B parametrli model.',
    speed: 'Tezkor',
    badge: 'OpenRouter',
    icon: 'globe',
  },
  {
    id: 'qwen/qwen-2.5-72b-instruct',
    name: 'Qwen 2.5 72B',
    provider: 'openrouter',
    tag: 'OpenRouter / Qwen',
    description: 'Koʻp tilli va yuqori samarali 72B modeli.',
    speed: 'Tezkor',
    badge: 'OpenRouter',
    icon: 'globe',
  },
  {
    id: 'openai/gpt-4o',
    name: 'GPT-4o',
    provider: 'openrouter',
    tag: 'OpenRouter / OpenAI',
    description: 'OpenAI koʻp qirrali flagman modeli (rasm tahlilini qoʻllaydi).',
    speed: 'Tezkor',
    badge: 'OpenRouter',
    icon: 'sparkles',
  },
  {
    id: 'openai/gpt-4o-mini',
    name: 'GPT-4o Mini',
    provider: 'openrouter',
    tag: 'OpenRouter / OpenAI',
    description: 'OpenAI ixcham, yengil va tejamkor modeli.',
    speed: 'Eng tezkor',
    badge: 'OpenRouter',
    icon: 'zap',
  },
  {
    id: 'anthropic/claude-3.5-sonnet',
    name: 'Claude 3.5 Sonnet',
    provider: 'openrouter',
    tag: 'OpenRouter / Anthropic',
    description: 'Anthropic modeli: tabiiy yozuv va kod yozishda kuchli.',
    speed: 'Oʻrtacha',
    badge: 'OpenRouter',
    icon: 'code',
  },
];

export type ModelId = string;
/** @deprecated `ModelId` dan foydalaning. */
export type GeminiModelId = ModelId;

export const DEFAULT_MODEL_ID: ModelId = 'gemini-3.8-flash';

export const MODEL_STORAGE_KEY = 'core_ai_selected_model';

export function isValidModelId(id: unknown): id is ModelId {
  return typeof id === 'string' && AVAILABLE_MODELS.some((m) => m.id === id);
}

export function getModelDefinition(id: string): ModelDefinition {
  return AVAILABLE_MODELS.find((m) => m.id === id) ?? AVAILABLE_MODELS[0];
}

/**
 * Model nomini qatʼiy tekshiradi.
 * Ruxsat etilmagan yoki eskirgan (masalan, oʻchirilgan gemini-2.0-flash) nomlar kelsa,
 * doimo xavfsiz standart model qaytariladi.
 */
export function sanitizeModelId(id: unknown): ModelId {
  return isValidModelId(id) ? id : DEFAULT_MODEL_ID;
}

export function getStoredModel(): ModelId {
  if (typeof window === 'undefined') return DEFAULT_MODEL_ID;
  try {
    return sanitizeModelId(localStorage.getItem(MODEL_STORAGE_KEY));
  } catch {
    return DEFAULT_MODEL_ID;
  }
}

export function setStoredModel(model: ModelId): void {
  if (typeof window === 'undefined') return;
  const safe = sanitizeModelId(model);
  try {
    localStorage.setItem(MODEL_STORAGE_KEY, safe);
  } catch {
    // localStorage cheklovi
  }
  window.dispatchEvent(new Event('core_ai_model_change'));
}

export function subscribeModelChange(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  window.addEventListener('storage', callback);
  window.addEventListener('core_ai_model_change', callback);
  return () => {
    window.removeEventListener('storage', callback);
    window.removeEventListener('core_ai_model_change', callback);
  };
}
