/** Xom PCM (16-bit, little-endian) ma'lumotiga WAV sarlavhasini qoʻshadi — brauzer <audio> uni shundagina oʻynaydi. */
export function pcm16ToWav(pcm: Uint8Array, sampleRate = 24000, channels = 1): Uint8Array {
  const bytesPerSample = 2;
  const blockAlign = channels * bytesPerSample;
  const header = new ArrayBuffer(44);
  const view = new DataView(header);
  const writeText = (offset: number, text: string) => {
    for (let i = 0; i < text.length; i++) view.setUint8(offset + i, text.charCodeAt(i));
  };

  writeText(0, 'RIFF');
  view.setUint32(4, 36 + pcm.byteLength, true);
  writeText(8, 'WAVE');
  writeText(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, channels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bytesPerSample * 8, true);
  writeText(36, 'data');
  view.setUint32(40, pcm.byteLength, true);

  const out = new Uint8Array(44 + pcm.byteLength);
  out.set(new Uint8Array(header), 0);
  out.set(pcm, 44);
  return out;
}

export interface AudioPayload {
  bytes: Uint8Array;
  contentType: string;
}

/**
 * Gemini TTS javobidagi audio MIME turiga qarab tayyor audio fayl hosil qiladi:
 * xom PCM (`audio/L16;rate=24000`, `audio/pcm`) WAV ga oʻraladi, tayyor formatlar (wav/mp3/ogg) oʻzgarishsiz qoladi.
 */
export function toPlayableAudio(base64: string, mimeType?: string): AudioPayload {
  const bytes = new Uint8Array(Buffer.from(base64, 'base64'));
  const mime = (mimeType ?? '').toLowerCase();

  const isContainer = /audio\/(wav|x-wav|wave|mpeg|mp3|ogg|webm|mp4|aac|flac)/.test(mime);
  if (isContainer) {
    const type = mime.split(';')[0].replace('audio/x-wav', 'audio/wav').replace('audio/wave', 'audio/wav');
    return { bytes, contentType: type };
  }

  const rate = Number(/rate=(\d+)/.exec(mime)?.[1]) || 24000;
  const channels = Number(/channels=(\d+)/.exec(mime)?.[1]) || 1;
  return { bytes: pcm16ToWav(bytes, rate, channels), contentType: 'audio/wav' };
}
