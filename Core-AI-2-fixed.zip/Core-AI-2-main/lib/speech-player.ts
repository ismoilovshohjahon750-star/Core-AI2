'use client';

import {
  chunkTextForSpeech,
  cleanTextForSpeech,
  selectBestVoice,
} from './speech-utils.ts';

export type SpeechState = 'idle' | 'loading' | 'playing';

type Listener = () => void;

class SpeechPlayer {
  private activeId: string | null = null;
  private state: SpeechState = 'idle';
  private listeners: Set<Listener> = new Set();
  private currentAudio: HTMLAudioElement | null = null;
  private audioUrl: string | null = null;
  private heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private watchdogTimer: ReturnType<typeof setTimeout> | null = null;
  private abortController: AbortController | null = null;
  private retainedUtterances: Set<SpeechSynthesisUtterance> = new Set();
  private cachedVoices: SpeechSynthesisVoice[] = [];

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.refreshVoices();
      try {
        window.speechSynthesis.onvoiceschanged = () => {
          this.refreshVoices();
        };
      } catch {
        // ayrim brauzerlar ruxsat bermasligi mumkin
      }
    }
  }

  private refreshVoices() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const v = window.speechSynthesis.getVoices();
      if (v && v.length > 0) {
        this.cachedVoices = v;
      }
    }
  }

  public subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    for (const listener of this.listeners) {
      try {
        listener();
      } catch {
        // xatolik yutildi
      }
    }
  }

  public getActiveId(): string | null {
    return this.activeId;
  }

  public getState(): SpeechState {
    return this.state;
  }

  public stop() {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }

    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio.onended = null;
      this.currentAudio.onerror = null;
      this.currentAudio = null;
    }

    if (this.audioUrl) {
      URL.revokeObjectURL(this.audioUrl);
      this.audioUrl = null;
    }

    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }

    if (this.watchdogTimer) {
      clearTimeout(this.watchdogTimer);
      this.watchdogTimer = null;
    }

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // xatolik yutildi
      }
    }

    this.retainedUtterances.clear();
    this.activeId = null;
    this.state = 'idle';
    this.notify();
  }

  public async toggle(id: string, text: string) {
    if (this.activeId === id) {
      this.stop();
      return;
    }
    await this.play(id, text);
  }

  public async play(id: string, text: string) {
    this.stop();

    const cleaned = cleanTextForSpeech(text);
    if (!cleaned) return;

    this.activeId = id;
    this.state = 'loading';
    this.notify();

    // 1-bosqich: Yuqori sifatli toʻliq Gemini AI ovozi (butun javobni boshidan oxirigacha oʻqish)
    const controller = new AbortController();
    this.abortController = controller;

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleaned }),
        signal: controller.signal,
      });

      if (res.ok) {
        const blob = await res.blob();
        if (blob.size > 100 && !controller.signal.aborted && this.activeId === id) {
          const url = URL.createObjectURL(blob);
          this.audioUrl = url;
          const audio = new Audio(url);
          this.currentAudio = audio;

          audio.onended = () => {
            if (this.activeId === id) {
              this.stop();
            }
          };

          audio.onerror = () => {
            if (this.activeId === id) {
              this.playWithWebSpeech(id, cleaned);
            }
          };

          await audio.play();
          this.state = 'playing';
          this.notify();
          return;
        }
      }
    } catch {
      // Server TTS ishlamasa yoki soʻrov bekor qilinsa, brauzer nutqiga oʻtiladi
    }

    if (controller.signal.aborted || this.activeId !== id) return;

    // 2-bosqich: Zaxira sifatida brauzerning Web Speech tizimi
    this.playWithWebSpeech(id, cleaned);
  }

  /**
   * Zaxira: Brauzerning oʻrnatilgan Web Speech tizimi
   */
  private playWithWebSpeech(id: string, cleanedText: string) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      this.stop();
      return;
    }

    try {
      window.speechSynthesis.cancel();
    } catch {
      // yutildi
    }

    const chunks = chunkTextForSpeech(cleanedText, 130);
    if (chunks.length === 0) {
      this.stop();
      return;
    }

    if (this.cachedVoices.length === 0) {
      this.refreshVoices();
    }

    const voices = this.cachedVoices.length > 0 ? this.cachedVoices : window.speechSynthesis.getVoices();
    const bestVoice = selectBestVoice(voices, cleanedText);

    let currentIndex = 0;
    this.state = 'playing';
    this.notify();

    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = setInterval(() => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
          window.speechSynthesis.pause();
          window.speechSynthesis.resume();
        }
      }
    }, 3000);

    const speakNext = () => {
      if (this.activeId !== id) return;

      if (this.watchdogTimer) {
        clearTimeout(this.watchdogTimer);
        this.watchdogTimer = null;
      }

      if (currentIndex >= chunks.length) {
        this.stop();
        return;
      }

      const chunk = chunks[currentIndex];
      currentIndex++;

      const utterance = new SpeechSynthesisUtterance(chunk);
      this.retainedUtterances.add(utterance);

      if (bestVoice) {
        utterance.voice = bestVoice as SpeechSynthesisVoice;
        utterance.lang = bestVoice.lang;
      } else {
        utterance.lang = 'uz-UZ';
      }

      utterance.rate = 1.0;
      utterance.pitch = 1.0;

      let advanced = false;
      const advance = () => {
        if (advanced) return;
        advanced = true;
        this.retainedUtterances.delete(utterance);

        if (this.watchdogTimer) {
          clearTimeout(this.watchdogTimer);
          this.watchdogTimer = null;
        }

        if (this.activeId === id) {
          setTimeout(() => {
            if (this.activeId === id) {
              speakNext();
            }
          }, 30);
        }
      };

      utterance.onend = () => {
        advance();
      };

      utterance.onerror = () => {
        advance();
      };

      const expectedDurationMs = Math.max(3500, chunk.length * 110 + 3500);
      this.watchdogTimer = setTimeout(() => {
        if (!advanced && this.activeId === id) {
          advance();
        }
      }, expectedDurationMs);

      try {
        window.speechSynthesis.speak(utterance);
      } catch {
        advance();
      }
    };

    speakNext();
  }
}

export const speechPlayer = new SpeechPlayer();
