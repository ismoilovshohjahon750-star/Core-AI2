export const APP_NAME = 'Core AI';

/** Yon paneldagi profil nomi. `.env.local` ichida NEXT_PUBLIC_USER_NAME bilan oʻzgartiriladi. */
export const USER_NAME = process.env.NEXT_PUBLIC_USER_NAME?.trim() || 'Shohjahon Ismoilov';

export function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'CA';
  const first = parts[0][0] ?? '';
  const second = parts.length > 1 ? parts[parts.length - 1][0] ?? '' : '';
  return (first + second).toUpperCase();
}
