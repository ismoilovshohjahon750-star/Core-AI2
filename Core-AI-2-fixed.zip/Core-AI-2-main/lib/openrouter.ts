import {
  FULL_ATTACHMENT_TURNS,
  MAX_HISTORY_MESSAGES,
  textAttachmentToPrompt,
  type IncomingMessage,
} from './gemini.ts';

type TextPart = { type: 'text'; text: string };
type ImagePart = { type: 'image_url'; image_url: { url: string } };

export interface OpenAiMessage {
  role: 'system' | 'user' | 'assistant';
  content: string | Array<TextPart | ImagePart>;
}

const IMAGE_MIME = ['image/png', 'image/jpeg', 'image/webp'];
const DEFAULT_FILE_PROMPT = 'Ushbu biriktirilgan fayl mazmunini tahlil qiling va u boʻyicha toʻliq maʼlumot bering.';

/**
 * Suhbat tarixini OpenAI-mos (OpenRouter) formatiga oʻtkazadi.
 * Xato xabarlar tashlanadi, fayllar (matn va rasm) qoʻshiladi, birinchi xabar doim foydalanuvchiniki.
 */
export function toOpenRouterMessages(messages: IncomingMessage[], systemInstruction: string): OpenAiMessage[] {
  const recent = messages.slice(-MAX_HISTORY_MESSAGES).filter((m) => !m.error);
  const userIndexes = recent.map((m, i) => (m.role === 'user' ? i : -1)).filter((i) => i >= 0);
  const fullFrom = new Set(userIndexes.slice(-FULL_ATTACHMENT_TURNS));

  const out: OpenAiMessage[] = [];
  recent.forEach((m, i) => {
    const text = m.content?.trim() ?? '';

    if (m.role === 'assistant') {
      if (text) out.push({ role: 'assistant', content: text });
      return;
    }
    if (m.role !== 'user') return;

    const parts: Array<TextPart | ImagePart> = [];
    for (const att of m.attachments ?? []) {
      if (!fullFrom.has(i)) {
        parts.push({ type: 'text', text: `[Avval biriktirilgan fayl: ${att.name}]` });
      } else if (att.textContent) {
        parts.push({ type: 'text', text: textAttachmentToPrompt(att.name, att.textContent) });
      } else if (att.dataUrl && IMAGE_MIME.includes(att.type)) {
        parts.push({ type: 'image_url', image_url: { url: att.dataUrl } });
      } else {
        parts.push({
          type: 'text',
          text: `[Biriktirilgan fayl: ${att.name} — bu model ushbu fayl turini oʻqiy olmaydi. Gemini modelini tanlang.]`,
        });
      }
    }
    if (text) parts.push({ type: 'text', text });
    else if (parts.length > 0) parts.push({ type: 'text', text: DEFAULT_FILE_PROMPT });
    if (parts.length === 0) return;

    // Faqat matndan iborat xabarlarni oddiy satr sifatida yuboramiz (barcha modellar bilan mos).
    const onlyText = parts.every((p) => p.type === 'text');
    out.push({
      role: 'user',
      content: onlyText ? parts.map((p) => (p as TextPart).text).join('\n\n') : parts,
    });
  });

  while (out.length > 0 && out[0].role !== 'user') out.shift();
  return [{ role: 'system', content: systemInstruction }, ...out];
}
