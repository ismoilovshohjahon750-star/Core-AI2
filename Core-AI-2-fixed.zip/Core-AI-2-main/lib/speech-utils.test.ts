import test from 'node:test';
import assert from 'node:assert/strict';
import { cleanTextForSpeech, chunkTextForSpeech, selectBestVoice, splitIntoTTSParagraphs } from './speech-utils.ts';

test('cleanTextForSpeech kod va markdown belgilarini tozalaydi', () => {
  const md = `# Sarlavha
Bu yerda [havola](https://google.com) va \`inline kod\` mavjud.

\`\`\`js
console.log("Salom");
\`\`\`

- Birinchi nuqta
- Ikkinchi nuqta
*Qalin* va _kursiv_.`;

  const result = cleanTextForSpeech(md);
  assert.equal(result.includes('console.log'), false);
  assert.equal(result.includes('https://'), false);
  assert.equal(result.includes('#'), false);
  assert.equal(result.includes('havola'), true);
  assert.equal(result.includes('Birinchi nuqta'), true);
});

test('chunkTextForSpeech uzun matnlarni gaplar chegarasida qirqadi', () => {
  const text = 'Bu birinchi gap. Bu ikkinchi gap. Bu uchinchi juda uzun va batafsil tushuntirilgan gap. Va yakuniy xulosa gap!';
  const chunks = chunkTextForSpeech(text, 50);
  assert.ok(chunks.length > 1);
  assert.ok(chunks.every((c) => c.length <= 70));
});

test('chunkTextForSpeech juda uzun nuqtasiz matnlarni ham qatʼiy limitda boʻladi', () => {
  const continuousLongText = 'Bu juda uzun tushuntirish va unda birorta ham nuqta belgisi qoyilmagan '.repeat(10);
  const chunks = chunkTextForSpeech(continuousLongText, 130);
  assert.ok(chunks.length > 3);
  assert.ok(chunks.every((c) => c.length <= 130));
});

test('splitIntoTTSParagraphs matnni toʻliq va soʻzlarni yoʻqotmasdan qismlarga ajratadi', () => {
  const text = 'Birinchi qism. '.repeat(40) + 'Oxirgi jumla.';
  const paragraphs = splitIntoTTSParagraphs(text, 400);
  assert.ok(paragraphs.length > 1);
  assert.ok(paragraphs.every((p) => p.length <= 400));
  assert.ok(paragraphs[paragraphs.length - 1].includes('Oxirgi jumla.'));
});

test('selectBestVoice oʻzbek yoki turk ovozini afzal koʻradi', () => {
  const voices = [
    { lang: 'en-US', name: 'Samantha' },
    { lang: 'tr-TR', name: 'Yelda' },
    { lang: 'ru-RU', name: 'Milena' },
  ];

  const chosen = selectBestVoice(voices, 'Salom dunyo!');
  assert.equal(chosen?.lang, 'tr-TR');

  const voicesWithUz = [
    { lang: 'en-US', name: 'Samantha' },
    { lang: 'uz-UZ', name: 'Dilnoza' },
    { lang: 'tr-TR', name: 'Yelda' },
  ];
  const chosenUz = selectBestVoice(voicesWithUz, 'Salom dunyo!');
  assert.equal(chosenUz?.lang, 'uz-UZ');
});
