import { stripEmojis } from './chat-utils.ts';

/**
 * Matnni nutqqa aylantirish uchun tozalaydi:
 * - Markdown belgilari, kod bloklari, havolalarni tozalaydi
 * - Emojilarni olib tashlaydi
 * - Ortiqcha boʻshliqlarni yoʻqotadi
 */
export function cleanTextForSpeech(markdown: string): string {
  if (!markdown) return '';
  return stripEmojis(markdown)
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]*)`/g, '$1')
    .replace(/https?:\/\/\S+/gi, ' ')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/[*_~>|#]/g, ' ')
    .replace(/^\s*[-*+]\s+/gm, ' ')
    .replace(/^\s*\d+\.\s+/gm, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Har qanday uzunlikdagi matnni (hujjat, katta maqola, bosqichma-bosqich kod tushuntirishlari)
 * hech qanday boʻlagi tushib qolmasdan yoki kesilmasdan toʻliq oʻqilishini kafolatlaydi.
 * Har bir boʻlak maksimal maxChunkLength (standart 130 belgi) gacha saqlanadi.
 */
export function chunkTextForSpeech(text: string, maxChunkLength = 130): string[] {
  const cleaned = cleanTextForSpeech(text);
  if (!cleaned) return [];
  if (cleaned.length <= maxChunkLength) return [cleaned];

  // Maxsus atamalardagi nuqtalarni soʻz chegarasi sifatida qabul qilmaslik
  const safeText = cleaned
    .replace(/(Next|Node|Vue|Nuxt)\.js/gi, '$1 js')
    .replace(/(\d+)\.(\d+)/g, '$1 butun $2');

  const sentenceRegex = /[^.!?;\n]+[.!?;\n]+|[^.!?;\n]+$/g;
  const rawSentences = safeText.match(sentenceRegex) || [safeText];

  const atomicPhrases: string[] = [];

  for (const sentence of rawSentences) {
    const sTrimmed = sentence.trim();
    if (!sTrimmed) continue;

    if (sTrimmed.length <= maxChunkLength) {
      atomicPhrases.push(sTrimmed);
    } else {
      // Agar gap juda uzun bo'lsa (masalan vergullar yoki tire bilan ajratilgan murakkab gap)
      const subParts = sTrimmed.split(/([,:\u2014\-]\s+)/);
      let currentSub = '';

      for (let i = 0; i < subParts.length; i++) {
        const part = subParts[i];
        if (!part) continue;

        if ((currentSub + part).length <= maxChunkLength) {
          currentSub += part;
        } else {
          if (currentSub.trim()) atomicPhrases.push(currentSub.trim());
          if (part.length <= maxChunkLength) {
            currentSub = part;
          } else {
            // Hatto bitta ibora ham chegaradan oshsa, so'zlar bo'yicha bo'lamiz
            const words = part.split(/\s+/);
            let wordChunk = '';
            for (const w of words) {
              if ((wordChunk + ' ' + w).length <= maxChunkLength) {
                wordChunk = wordChunk ? wordChunk + ' ' + w : w;
              } else {
                if (wordChunk.trim()) atomicPhrases.push(wordChunk.trim());
                wordChunk = w;
              }
            }
            currentSub = wordChunk;
          }
        }
      }
      if (currentSub.trim()) atomicPhrases.push(currentSub.trim());
    }
  }

  // Kichik iboralarni maxChunkLength gacha birlashtirib, tabiiy nafas olish tanaffuslari bilan optimal bo'laklar yig'amiz
  const chunks: string[] = [];
  let current = '';

  for (const phrase of atomicPhrases) {
    const trimmed = phrase.trim();
    if (!trimmed) continue;

    if (!current) {
      current = trimmed;
    } else if ((current + ' ' + trimmed).length <= maxChunkLength) {
      current += ' ' + trimmed;
    } else {
      chunks.push(current);
      current = trimmed;
    }
  }

  if (current.trim()) {
    chunks.push(current.trim());
  }

  return chunks;
}

/**
 * Matnni tabiiy abzatslar va gaplar chegarasida 500-700 belgilik yirik qismlarga ajratadi.
 * Bu boʻlaklar ketma-ket uzluksiz oʻqilishini kafolatlaydi.
 */
export function splitIntoTTSParagraphs(text: string, maxChars = 650): string[] {
  const cleaned = cleanTextForSpeech(text);
  if (!cleaned) return [];
  if (cleaned.length <= maxChars) return [cleaned];

  const parts = cleaned.match(/[^.!?;\n]+[.!?;\n]+|[^.!?;\n]+$/g) || [cleaned];

  const sections: string[] = [];
  let current = '';

  for (const part of parts) {
    const trimmed = part.trim();
    if (!trimmed) continue;

    if (!current) {
      current = trimmed;
    } else if ((current + ' ' + trimmed).length <= maxChars) {
      current += ' ' + trimmed;
    } else {
      sections.push(current);
      if (trimmed.length > maxChars) {
        const subWords = trimmed.split(/\s+/);
        let wordSec = '';
        for (const w of subWords) {
          if ((wordSec + ' ' + w).length <= maxChars) {
            wordSec = wordSec ? wordSec + ' ' + w : w;
          } else {
            if (wordSec.trim()) sections.push(wordSec.trim());
            wordSec = w;
          }
        }
        current = wordSec;
      } else {
        current = trimmed;
      }
    }
  }

  if (current.trim()) {
    sections.push(current.trim());
  }

  return sections;
}

export interface VoiceItem {
  lang: string;
  name: string;
  default?: boolean;
}

/**
 * Mavjud brauzer ovozlari orasidan eng mosini tanlaydi:
 * 1. Oʻzbek tili (`uz-UZ` yoki `uz`)
 * 2. Agar matn kirillda boʻlsa — rus tili (`ru-RU`)
 * 3. Turk tili (`tr-TR` yoki `tr` — lotin oʻzbek tili fonetikasiga eng yaqin va aniq oʻqiydi)
 * 4. Rus tili (`ru-RU`)
 * 5. Tizim standart ovozi
 */
export function selectBestVoice<T extends VoiceItem>(voices: T[], text = ''): T | null {
  if (!voices || voices.length === 0) return null;

  const normalize = (l: string) => l.toLowerCase().replace(/_/g, '-');

  const uzVoice = voices.find((v) => normalize(v.lang).startsWith('uz'));
  if (uzVoice) return uzVoice;

  const hasCyrillic = /[\u0400-\u04FF]/.test(text);
  if (hasCyrillic) {
    const ruVoice = voices.find((v) => normalize(v.lang).startsWith('ru'));
    if (ruVoice) return ruVoice;
  }

  const trVoice = voices.find((v) => normalize(v.lang).startsWith('tr'));
  if (trVoice) return trVoice;

  const ruVoice = voices.find((v) => normalize(v.lang).startsWith('ru'));
  if (ruVoice) return ruVoice;

  const def = voices.find((v) => v.default);
  return def || voices[0] || null;
}
