import { useCallback, useSyncExternalStore } from 'react';

const DEFAULT_BREAKPOINT = 1024;

/** Ekran kengligi `breakpoint` dan kichik boʻlsa true. Server tomonida false qaytaradi. */
export function useIsMobile(breakpoint = DEFAULT_BREAKPOINT) {
  const query = `(max-width: ${breakpoint - 1}px)`;

  // subscribe barqaror boʻlishi shart — aks holda har renderda qayta obuna boʻlinadi.
  const subscribe = useCallback(
    (callback: () => void) => {
      const mql = window.matchMedia(query);
      mql.addEventListener('change', callback);
      return () => mql.removeEventListener('change', callback);
    },
    [query]
  );

  return useSyncExternalStore(
    subscribe,
    () => window.matchMedia(query).matches,
    () => false
  );
}
