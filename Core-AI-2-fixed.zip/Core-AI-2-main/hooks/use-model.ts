'use client';

import { useSyncExternalStore } from 'react';
import { DEFAULT_MODEL_ID, getStoredModel, subscribeModelChange, type ModelId } from '@/lib/model-config';

/** Sozlamalarda tanlangan model (boshqa oynada oʻzgarsa ham yangilanadi). */
export function useStoredModel(): ModelId {
  return useSyncExternalStore(subscribeModelChange, getStoredModel, () => DEFAULT_MODEL_ID);
}
