'use client';

import { useCallback, useSyncExternalStore } from 'react';
import { USER_NAME } from '@/lib/config';

const KEY = 'core_ai_custom_name';
const EVENT = 'core_ai_name_change';

function getSnapshot(): string {
  try {
    return localStorage.getItem(KEY)?.trim() || USER_NAME;
  } catch {
    return USER_NAME;
  }
}

function subscribe(callback: () => void) {
  window.addEventListener('storage', callback);
  window.addEventListener(EVENT, callback);
  return () => {
    window.removeEventListener('storage', callback);
    window.removeEventListener(EVENT, callback);
  };
}

/** Koʻrinadigan ism: profil menyusi va sozlamalar bir xil manbadan foydalanadi. */
export function useUserName() {
  const userName = useSyncExternalStore(subscribe, getSnapshot, () => USER_NAME);

  const saveUserName = useCallback((value: string): boolean => {
    const trimmed = value.trim().slice(0, 50);
    if (!trimmed) return false;
    try {
      localStorage.setItem(KEY, trimmed);
    } catch {
      // localStorage cheklovi — ism faqat shu sessiyada yangilanmaydi
      return false;
    }
    window.dispatchEvent(new Event(EVENT));
    return true;
  }, []);

  return { userName, saveUserName };
}
