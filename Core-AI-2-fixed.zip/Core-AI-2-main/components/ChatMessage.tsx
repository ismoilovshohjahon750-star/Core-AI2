'use client';

import { memo, useCallback, useState, useSyncExternalStore } from 'react';
import { AlertCircle, Check, Copy, Loader2, RotateCcw, ThumbsDown, ThumbsUp, Volume2, VolumeX } from 'lucide-react';
import type { ChatAttachment, ChatMessageItem } from '@/lib/types';
import { isImageAttachment } from '@/lib/chat-utils';
import { downloadAttachment } from '@/lib/file-utils';
import { speechPlayer, type SpeechState } from '@/lib/speech-player';
import { cn } from '@/lib/utils';
import { LogoBadge } from './LogoBadge';
import { MarkdownRenderer } from './MarkdownRenderer';
import { AttachmentChip } from './AttachmentChip';

interface ChatMessageProps {
  message: ChatMessageItem;
  isLast: boolean;
  isStreaming: boolean;
  onRegenerate?: () => void;
  onReact: (id: string, reaction: 'liked' | 'disliked', value: boolean) => void;
  onPreviewImage: (att: ChatAttachment) => void;
}

function ActionButton({
  label,
  onClick,
  active,
  children,
}: {
  label: string;
  onClick: () => void;
  active?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      aria-label={label}
      aria-pressed={active}
      className={cn(
        'flex cursor-pointer items-center gap-1.5 rounded-lg p-2 text-subtle transition hover:bg-hover hover:text-fg',
        active && 'bg-accent-soft text-accent-strong hover:text-accent-strong'
      )}
    >
      {children}
    </button>
  );
}

const emptySubscribe = () => () => {};

export const ChatMessage = memo(function ChatMessage({
  message,
  isLast,
  isStreaming,
  onRegenerate,
  onReact,
  onPreviewImage,
}: ChatMessageProps) {
  const [copied, setCopied] = useState(false);

  const isClient = useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );

  const canSpeak = isClient && typeof window !== 'undefined' && ('speechSynthesis' in window || typeof Audio !== 'undefined');

  const subscribeSpeech = useCallback((onStoreChange: () => void) => {
    return speechPlayer.subscribe(onStoreChange);
  }, []);

  const getSpeechSnapshot = useCallback(() => {
    return speechPlayer.getActiveId() === message.id ? speechPlayer.getState() : 'idle';
  }, [message.id]);

  const speechState: SpeechState = useSyncExternalStore(
    subscribeSpeech,
    getSpeechSnapshot,
    () => 'idle'
  );

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // clipboard mavjud emas
    }
  };

  const toggleSpeech = () => {
    void speechPlayer.toggle(message.id, message.content);
  };

  if (message.role === 'user') {
    const attachments = message.attachments ?? [];
    return (
      <div className="flex w-full justify-end">
        <div className="flex max-w-[88%] flex-col items-end gap-2 sm:max-w-[80%]">
          {attachments.length > 0 && (
            <div className="flex flex-wrap justify-end gap-2">
              {attachments.map((att) => (
                <AttachmentChip
                  key={att.id}
                  attachment={att}
                  onPreview={isImageAttachment(att) && att.dataUrl ? () => onPreviewImage(att) : undefined}
                  onDownload={att.dataUrl || att.textContent ? () => downloadAttachment(att) : undefined}
                />
              ))}
            </div>
          )}
          {message.content && (
            <div className="rounded-2xl rounded-br-md bg-accent-soft px-4 py-2.5 text-[15.5px] leading-relaxed text-fg">
              <p className="whitespace-pre-wrap break-words">{message.content}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  const waiting = isStreaming && !message.content;

  return (
    <div className="group flex w-full items-start gap-3">
      <LogoBadge size="sm" className="mt-1" />
      <div className="min-w-0 flex-1">
        {waiting ? (
          <div className="flex items-center gap-1.5 py-2.5" role="status" aria-label="Core AI javob tayyorlamoqda">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="pulse-dot h-2 w-2 rounded-full bg-accent"
                style={{ animationDelay: `${i * 0.16}s` }}
              />
            ))}
          </div>
        ) : message.error ? (
          <div className="flex items-start gap-2.5 rounded-xl border border-danger/30 bg-danger-soft px-4 py-3 text-sm leading-relaxed text-fg">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-danger" aria-hidden />
            <p>{message.content}</p>
          </div>
        ) : (
          <MarkdownRenderer content={message.content} />
        )}

        {!waiting && !(isStreaming && isLast) && (
          <div
            className={cn(
              'mt-1.5 -ml-2 flex flex-wrap items-center gap-0.5 transition-opacity',
              !isLast && 'md:opacity-0 md:group-focus-within:opacity-100 md:group-hover:opacity-100'
            )}
          >
            {!message.error && (
              <>
                <ActionButton label={copied ? 'Nusxalandi' : 'Nusxalash'} onClick={copy}>
                  {copied ? <Check className="h-4 w-4 text-ok" aria-hidden /> : <Copy className="h-4 w-4" aria-hidden />}
                </ActionButton>
                <ActionButton
                  label="Foydali javob"
                  active={message.liked}
                  onClick={() => onReact(message.id, 'liked', !message.liked)}
                >
                  <ThumbsUp className="h-4 w-4" aria-hidden />
                </ActionButton>
                <ActionButton
                  label="Foydasiz javob"
                  active={message.disliked}
                  onClick={() => onReact(message.id, 'disliked', !message.disliked)}
                >
                  <ThumbsDown className="h-4 w-4" aria-hidden />
                </ActionButton>
              </>
            )}
            {onRegenerate && (
              <ActionButton label={message.error ? 'Qayta urinish' : 'Javobni qayta yaratish'} onClick={onRegenerate}>
                <RotateCcw className="h-4 w-4" aria-hidden />
                {message.error && <span className="pr-1 text-xs font-medium">Qayta urinish</span>}
              </ActionButton>
            )}
            {!message.error && canSpeak && (
              <ActionButton
                label={
                  speechState === 'loading'
                    ? 'Ovoz tayyorlanmoqda...'
                    : speechState === 'playing'
                      ? 'Ovozni toʻxtatish'
                      : 'Ovoz chiqarib oʻqish'
                }
                onClick={toggleSpeech}
                active={speechState === 'playing'}
              >
                {speechState === 'loading' ? (
                  <Loader2 className="h-4 w-4 animate-spin text-accent" aria-hidden />
                ) : speechState === 'playing' ? (
                  <VolumeX className="h-4 w-4 text-accent" aria-hidden />
                ) : (
                  <Volume2 className="h-4 w-4" aria-hidden />
                )}
              </ActionButton>
            )}
          </div>
        )}
      </div>
    </div>
  );
});
