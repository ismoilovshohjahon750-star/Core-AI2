'use client';

import { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Bot,
  Brain,
  Check,
  ChevronDown,
  Code,
  Cpu,
  Database,
  Globe,
  Info,
  Laptop,
  Menu,
  Moon,
  Paintbrush,
  Sparkles,
  Sun,
  Trash2,
  User,
  Zap,
  type LucideIcon,
} from 'lucide-react';
import type { ThemePreference } from '@/lib/theme';
import {
  AVAILABLE_MODELS,
  getModelDefinition,
  setStoredModel,
  type ModelDefinition,
  type ModelIcon,
  type ModelProvider,
} from '@/lib/model-config';
import { useStoredModel } from '@/hooks/use-model';
import { useUserName } from '@/hooks/use-user-name';
import { cn } from '@/lib/utils';
import { Avatar } from './Avatar';

interface SettingsViewProps {
  onBack: () => void;
  preference: ThemePreference;
  onChangeTheme: (pref: ThemePreference) => void;
  onDeleteAll: () => void;
  hasConversations: boolean;
  conversationsCount: number;
  sidebarVisible: boolean;
  isMobile: boolean;
  onToggleSidebar: () => void;
}

const THEME_OPTIONS: Array<{ value: ThemePreference; label: string; hint: string; icon: LucideIcon }> = [
  { value: 'system', label: 'Qurilma', hint: 'Tizim sozlamasiga moslashadi', icon: Laptop },
  { value: 'light', label: 'Yorugʻ', hint: 'Kunduzgi qulay koʻrinish', icon: Sun },
  { value: 'dark', label: 'Qorongʻi', hint: 'Kechki qulay koʻrinish', icon: Moon },
];

const MODEL_ICONS: Record<ModelIcon, LucideIcon> = {
  sparkles: Sparkles,
  zap: Zap,
  cpu: Cpu,
  bot: Bot,
  brain: Brain,
  globe: Globe,
  code: Code,
};

const PROVIDER_LABELS: Record<ModelProvider, { title: string; hint: string }> = {
  gemini: { title: 'Google Gemini', hint: 'GEMINI_API_KEY talab qilinadi' },
  openrouter: { title: 'OpenRouter', hint: 'OPENROUTER_API_KEY talab qilinadi' },
};

const MODEL_GROUPS: Array<{ provider: ModelProvider; models: ModelDefinition[] }> = (['gemini', 'openrouter'] as const).map(
  (provider) => ({ provider, models: AVAILABLE_MODELS.filter((m) => m.provider === provider) })
);

export function SettingsView({
  onBack,
  preference,
  onChangeTheme,
  onDeleteAll,
  hasConversations,
  conversationsCount,
  sidebarVisible,
  isMobile,
  onToggleSidebar,
}: SettingsViewProps) {
  const currentModel = useStoredModel();
  const { userName, saveUserName } = useUserName();

  const [modelsOpen, setModelsOpen] = useState(false);
  const activeModel = getModelDefinition(currentModel);
  const ActiveModelIcon = MODEL_ICONS[activeModel.icon];

  const [editName, setEditName] = useState(userName);
  const [nameSaved, setNameSaved] = useState(false);
  const savedTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => {
    if (savedTimer.current) clearTimeout(savedTimer.current);
  }, []);

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!saveUserName(editName)) return;
    setNameSaved(true);
    if (savedTimer.current) clearTimeout(savedTimer.current);
    savedTimer.current = setTimeout(() => setNameSaved(false), 2000);
  };

  return (
    <div className="flex h-full min-w-0 flex-1 flex-col bg-canvas text-fg">
      {/* 1. Yuqori sarlavha paneli (Header) */}
      <header className="flex h-14 shrink-0 items-center justify-between gap-3 border-b border-line px-3 pt-[env(safe-area-inset-top)] sm:px-6">
        <div className="flex min-w-0 items-center gap-2">
          {(!sidebarVisible || isMobile) && (
            <button
              type="button"
              onClick={onToggleSidebar}
              title="Panelni ochish"
              aria-label="Panelni ochish"
              className="cursor-pointer rounded-xl p-2 text-muted transition hover:bg-hover hover:text-fg"
            >
              <Menu className="h-5 w-5" aria-hidden />
            </button>
          )}

          <button
            type="button"
            onClick={onBack}
            className="flex cursor-pointer items-center gap-1.5 rounded-xl border border-line bg-panel px-3 py-1.5 text-xs font-semibold text-fg transition hover:bg-hover hover:border-line-strong"
            title="Suhbatga qaytish"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden />
            <span>Suhbatga qaytish</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-subtle">Sozlamalar boʻlimi</span>
        </div>
      </header>

      {/* 2. Asosiy toʻliq skroll qilinuvchi kontent */}
      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-8 sm:px-8">
        <div className="mx-auto max-w-3xl space-y-10 pb-16">
          {/* Sahifa kirish qismi */}
          <div className="border-b border-line pb-6">
            <h1 className="text-2xl font-bold tracking-tight text-fg">Sozlamalar</h1>
            <p className="mt-1.5 text-sm text-muted">
              AI modeli, vizual interfeys, foydalanuvchi hisobi va maʼlumotlar xavfsizligini boshqaring.
            </p>
          </div>

          {/* 1-boʻlim: AI Modeli (Ochib-yopiladigan) */}
          <section className="rounded-2xl border border-line bg-panel/50 overflow-hidden transition">
            <button
              type="button"
              onClick={() => setModelsOpen((prev) => !prev)}
              aria-expanded={modelsOpen}
              aria-controls="models-list-container"
              className="flex w-full cursor-pointer items-center justify-between gap-3 p-4 text-left transition hover:bg-hover"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent-soft text-accent-strong">
                  <ActiveModelIcon className="h-5 w-5" aria-hidden />
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="text-base font-semibold text-fg">AI Modeli</h2>
                    <span className="rounded-md border border-line bg-canvas px-2 py-0.5 text-[11px] font-semibold text-subtle">
                      {activeModel.badge}
                    </span>
                    <span className="rounded-full border border-line bg-canvas px-2 py-0.5 text-[10px] font-semibold text-muted">
                      {PROVIDER_LABELS[activeModel.provider].title}
                    </span>
                  </div>
                  <p className="truncate text-xs text-muted mt-0.5">
                    Joriy model: <span className="font-semibold text-fg">{activeModel.name}</span> · {activeModel.speed}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="hidden sm:inline-block text-xs font-medium text-subtle">
                  {modelsOpen ? 'Roʻyxatni yopish' : 'Roʻyxatni ochish'}
                </span>
                <div
                  className={cn(
                    'flex h-8 w-8 items-center justify-center rounded-xl border border-line bg-canvas text-subtle transition-transform duration-200',
                    modelsOpen ? 'rotate-180 text-fg border-line-strong' : ''
                  )}
                >
                  <ChevronDown className="h-4 w-4" aria-hidden />
                </div>
              </div>
            </button>

            {modelsOpen && (
              <div id="models-list-container" className="border-t border-line bg-canvas/30 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted">Tanlov avtomatik saqlanadi va keyingi savoldan kuchga kiradi.</p>
                  <span className="text-[11px] text-subtle">{AVAILABLE_MODELS.length} ta model mavjud</span>
                </div>

                <div className="space-y-5">
                  {MODEL_GROUPS.map(({ provider, models }) => (
                    <div key={provider} role="radiogroup" aria-label={PROVIDER_LABELS[provider].title} className="space-y-2.5">
                      <div className="flex items-baseline justify-between gap-2 px-0.5">
                        <h3 className="text-xs font-semibold uppercase tracking-wide text-subtle">
                          {PROVIDER_LABELS[provider].title}
                        </h3>
                        <span className="font-mono text-[11px] text-subtle">{PROVIDER_LABELS[provider].hint}</span>
                      </div>
                      {models.map((model) => {
                        const selected = currentModel === model.id;
                        const Icon = MODEL_ICONS[model.icon];
                        return (
                          <label
                            key={model.id}
                            className={cn(
                              'relative flex cursor-pointer items-start gap-3.5 rounded-xl border p-3.5 transition has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-accent',
                              selected
                                ? 'border-accent bg-accent-soft shadow-sm'
                                : 'border-line bg-panel hover:border-line-strong hover:bg-hover'
                            )}
                          >
                            <input
                              type="radio"
                              name="ai_model_setting"
                              value={model.id}
                              checked={selected}
                              onChange={() => setStoredModel(model.id)}
                              className="sr-only"
                            />
                            <div
                              className={cn(
                                'mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition',
                                selected ? 'bg-accent text-accent-fg' : 'border border-line bg-canvas text-subtle'
                              )}
                            >
                              <Icon className="h-4 w-4" aria-hidden />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-sm font-semibold text-fg">{model.name}</span>
                                <span className="rounded-md border border-line bg-canvas px-2 py-0.5 text-[10px] font-semibold text-subtle">
                                  {model.badge}
                                </span>
                                <span className="text-xs text-subtle">{model.speed}</span>
                              </div>
                              <p className="mt-1 text-xs leading-relaxed text-muted">{model.description}</p>
                            </div>
                            {selected && (
                              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent text-accent-fg">
                                <Check className="h-3 w-3 stroke-[3]" aria-hidden />
                              </span>
                            )}
                          </label>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>

          {/* 2-boʻlim: Mavzu va tashqi koʻrinish */}
          <section className="space-y-4 border-t border-line pt-8">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-accent-soft text-accent-strong">
                <Paintbrush className="h-4 w-4" aria-hidden />
              </div>
              <div>
                <h2 className="text-base font-semibold text-fg">Tashqi koʻrinish</h2>
                <p className="text-xs text-muted">Ilovaning ranglar mavzusini tanlang</p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              {THEME_OPTIONS.map(({ value, label, hint, icon: Icon }) => {
                const selected = preference === value;
                return (
                  <label
                    key={value}
                    className={cn(
                      'relative flex cursor-pointer flex-col items-center gap-2 rounded-2xl border p-4 text-center transition has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-accent',
                      selected
                        ? 'border-accent bg-accent-soft shadow-sm'
                        : 'border-line bg-panel/50 hover:bg-hover hover:border-line-strong'
                    )}
                  >
                    <input
                      type="radio"
                      name="theme_preference"
                      value={value}
                      checked={selected}
                      onChange={() => onChangeTheme(value)}
                      className="sr-only"
                    />
                    <Icon className={cn('h-6 w-6', selected ? 'text-accent-strong' : 'text-muted')} aria-hidden />
                    <div>
                      <p className="text-sm font-semibold text-fg">{label}</p>
                      <p className="mt-0.5 text-xs text-subtle">{hint}</p>
                    </div>
                    {selected && (
                      <span className="absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full bg-accent text-accent-fg">
                        <Check className="h-3 w-3 stroke-[3]" aria-hidden />
                      </span>
                    )}
                  </label>
                );
              })}
            </div>
          </section>

          {/* 3-boʻlim: Profil maʼlumotlari */}
          <section className="space-y-4 border-t border-line pt-8">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-accent-soft text-accent-strong">
                <User className="h-4 w-4" aria-hidden />
              </div>
              <div>
                <h2 className="text-base font-semibold text-fg">Foydalanuvchi profili</h2>
                <p className="text-xs text-muted">Shaxsiy hisob va koʻrinadigan ism sozlamalari</p>
              </div>
            </div>

            <div className="rounded-2xl border border-line bg-panel/50 p-5">
              <div className="flex items-center gap-4">
                <Avatar name={userName} size="lg" />
                <div className="min-w-0 flex-1">
                  <p className="text-base font-semibold text-fg">{userName}</p>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="text-xs text-subtle">Mahalliy brauzer hisobi</span>
                  </div>
                </div>
              </div>

              <form onSubmit={handleSaveName} className="mt-5 space-y-3 border-t border-line pt-4">
                <div>
                  <label htmlFor="settings-username-input" className="block text-xs font-medium text-subtle">
                    Koʻrinadigan ism
                  </label>
                  <input
                    id="settings-username-input"
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    maxLength={50}
                    className="mt-1.5 w-full rounded-xl border border-line bg-canvas px-3.5 py-2.5 text-sm text-fg outline-none transition focus:border-accent"
                  />
                </div>
                <div className="flex items-center justify-between pt-1">
                  {nameSaved ? (
                    <span role="status" className="flex items-center gap-1.5 text-xs text-ok">
                      <Check className="h-3.5 w-3.5" aria-hidden />
                      Ism saqlandi
                    </span>
                  ) : (
                    <span className="text-xs text-subtle">Profil nomi suhbatlarda koʻrsatiladi</span>
                  )}
                  <button
                    type="submit"
                    className="cursor-pointer rounded-xl bg-accent px-4 py-2 text-xs font-semibold text-accent-fg transition hover:bg-accent-strong"
                  >
                    Saqlash
                  </button>
                </div>
              </form>
            </div>
          </section>

          {/* 4-boʻlim: Maʼlumotlar xotirasi */}
          <section className="space-y-4 border-t border-line pt-8">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-accent-soft text-accent-strong">
                <Database className="h-4 w-4" aria-hidden />
              </div>
              <div>
                <h2 className="text-base font-semibold text-fg">Xotira va maʼlumotlar</h2>
                <p className="text-xs text-muted">Suhbatlar tarixi va qurilmadagi kesh boshqaruvi</p>
              </div>
            </div>

            <div className="rounded-2xl border border-line bg-panel/50 p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-fg">Saqlangan suhbatlar</p>
                  <p className="mt-0.5 text-xs text-subtle">
                    Hozirda qurilmangiz xotirasida {conversationsCount} ta suhbat mavjud.
                  </p>
                </div>
                <button
                  type="button"
                  disabled={!hasConversations}
                  onClick={onDeleteAll}
                  className="flex cursor-pointer items-center gap-2 rounded-xl border border-danger/40 px-4 py-2 text-xs font-semibold text-danger transition hover:bg-danger-soft disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-transparent"
                >
                  <Trash2 className="h-4 w-4" aria-hidden />
                  Barcha suhbatlarni oʻchirish
                </button>
              </div>
              <p className="mt-4 border-t border-line pt-3 text-[11px] leading-relaxed text-subtle">
                Barcha suhbatlar faqat shaxsiy brauzeringizning mahalliy xotirasida saqlanadi va begonalarga uzatilmaydi.
              </p>
            </div>
          </section>

          {/* 5-boʻlim: Dastur haqida */}
          <section className="space-y-4 border-t border-line pt-8">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-accent-soft text-accent-strong">
                <Info className="h-4 w-4" aria-hidden />
              </div>
              <div>
                <h2 className="text-base font-semibold text-fg">Dastur haqida</h2>
                <p className="text-xs text-muted">Core AI tizim maʼlumotlari</p>
              </div>
            </div>

            <div className="rounded-2xl border border-line bg-panel/50 p-5 text-xs text-muted leading-relaxed space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium text-fg">Ilova:</span>
                <span>Core AI</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium text-fg">Versiya:</span>
                <span>v1.0.0</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium text-fg">Neyron tarmoq:</span>
                <span>Google Gemini · OpenRouter</span>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
