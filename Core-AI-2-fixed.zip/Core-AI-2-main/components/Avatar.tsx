import { getInitials } from '@/lib/config';
import { cn } from '@/lib/utils';

const SIZES = { sm: 'h-9 w-9 text-xs', lg: 'h-12 w-12 text-sm' } as const;

/** Ism bosh harflaridan iborat doira. Ikkala mavzuda ham yetarli kontrast beradi. */
export function Avatar({ name, size = 'sm', className }: { name: string; size?: keyof typeof SIZES; className?: string }) {
  return (
    <span
      aria-hidden
      className={cn(
        'flex shrink-0 select-none items-center justify-center rounded-full bg-accent-soft font-semibold text-accent-strong',
        SIZES[size],
        className
      )}
    >
      {getInitials(name)}
    </span>
  );
}
