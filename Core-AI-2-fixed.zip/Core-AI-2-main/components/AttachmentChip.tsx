import { FileCode, FileText, Download, X } from 'lucide-react';
import type { ChatAttachment } from '@/lib/types';
import { formatFileSize, isCodeFileName, isImageAttachment } from '@/lib/chat-utils';
import { cn } from '@/lib/utils';

interface AttachmentChipProps {
  attachment: ChatAttachment;
  onRemove?: () => void;
  onDownload?: () => void;
  onPreview?: () => void;
  className?: string;
}

/** Fayl yoki rasm kartochkasi — yozish maydonida ham, xabarda ham bir xil koʻrinadi. */
export function AttachmentChip({ attachment, onRemove, onDownload, onPreview, className }: AttachmentChipProps) {
  const isImg = isImageAttachment(attachment) && !!attachment.dataUrl;
  const Icon = isCodeFileName(attachment.name) ? FileCode : FileText;

  const body = (
    <>
      {isImg ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={attachment.dataUrl} alt="" className="h-10 w-10 shrink-0 rounded-lg object-cover" />
      ) : (
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-accent-soft text-accent-strong">
          <Icon className="h-5 w-5" aria-hidden />
        </span>
      )}
      <span className="min-w-0 text-left">
        <span className="block max-w-[11rem] truncate text-[13px] font-medium text-fg">{attachment.name}</span>
        <span className="block text-[11px] text-subtle">{formatFileSize(attachment.size)}</span>
      </span>
    </>
  );

  return (
    <div className={cn('flex items-center gap-2.5 rounded-xl border border-line bg-panel p-1.5 pr-2', className)}>
      {onPreview ? (
        <button
          type="button"
          onClick={onPreview}
          className="flex min-w-0 cursor-pointer items-center gap-2.5 rounded-lg"
          aria-label={`Koʻrish: ${attachment.name}`}
        >
          {body}
        </button>
      ) : (
        <div className="flex min-w-0 items-center gap-2.5">{body}</div>
      )}
      {onDownload && (
        <button
          type="button"
          onClick={onDownload}
          className="cursor-pointer rounded-md p-1.5 text-subtle transition hover:bg-hover hover:text-fg"
          aria-label={`Yuklab olish: ${attachment.name}`}
        >
          <Download className="h-4 w-4" aria-hidden />
        </button>
      )}
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          className="cursor-pointer rounded-md p-1.5 text-subtle transition hover:bg-hover hover:text-fg"
          aria-label={`Olib tashlash: ${attachment.name}`}
        >
          <X className="h-4 w-4" aria-hidden />
        </button>
      )}
    </div>
  );
}
