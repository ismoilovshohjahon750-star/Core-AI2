'use client';

import { useEffect, useRef, useState } from 'react';
import { Check, ChevronRight, LifeBuoy, MoreHorizontal, Settings, User } from 'lucide-react';
import { useUserName } from '@/hooks/use-user-name';
import { cn } from '@/lib/utils';
import { Avatar } from './Avatar';
import { Dialog } from './Dialog';

interface ProfileMenuProps {
  onOpenSettings: () => void;
}

const ITEM_CLASS =
  'flex w-full cursor-pointer items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm font-medium transition hover:bg-hover';

const SHORTCUTS: Array<[string, string]> = [
  ['Xabar yuborish', 'Enter'],
  ['Yangi qatorga oʻtish', 'Shift + Enter'],
  ['Oynani yopish', 'Esc'],
];

export function ProfileMenu({ onOpenSettings }: ProfileMenuProps) {
  const [open, setOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);

  const { userName, saveUserName } = useUserName();
  const [editName, setEditName] = useState(userName);
  const [nameSaved, setNameSaved] = useState(false);

  const menuRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const savedTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => {
    if (savedTimer.current) clearTimeout(savedTimer.current);
  }, []);

  // Tashqariga bosganda yoki Esc bosilganda menyuni yopish
  useEffect(() => {
    if (!open) return;

    const onPointerDown = (e: MouseEvent) => {
      const target = e.target as Node;
      if (!menuRef.current?.contains(target) && !triggerRef.current?.contains(target)) setOpen(false);
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
        triggerRef.current?.focus();
      }
    };

    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [open]);

  const openProfile = () => {
    setOpen(false);
    setEditName(userName);
    setNameSaved(false);
    setProfileOpen(true);
  };

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!saveUserName(editName)) return;
    setNameSaved(true);
    if (savedTimer.current) clearTimeout(savedTimer.current);
    savedTimer.current = setTimeout(() => setNameSaved(false), 2000);
  };

  return (
    <>
      <div className="relative border-t border-line p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        {open && (
          <div
            ref={menuRef}
            role="menu"
            aria-label="Profil menyusi"
            className="anim-pop absolute bottom-full left-3 right-3 z-50 mb-2 overflow-hidden rounded-2xl border border-line-strong bg-raised p-1.5 text-fg shadow-float"
          >
            <button
              type="button"
              role="menuitem"
              onClick={openProfile}
              className="group flex w-full cursor-pointer items-center gap-3 rounded-xl p-2 text-left transition hover:bg-hover"
            >
              <Avatar name={userName} />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold">{userName}</span>
                <span className="block truncate text-xs text-subtle">Profilni tahrirlash</span>
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-subtle transition group-hover:text-fg" aria-hidden />
            </button>

            <div className="my-1 border-t border-line" />

            <button
              type="button"
              role="menuitem"
              onClick={() => {
                setOpen(false);
                onOpenSettings();
              }}
              className={ITEM_CLASS}
            >
              <Settings className="h-[18px] w-[18px] shrink-0 text-subtle" aria-hidden />
              <span>Sozlamalar</span>
            </button>

            <button
              type="button"
              role="menuitem"
              onClick={() => {
                setOpen(false);
                setHelpOpen(true);
              }}
              className={ITEM_CLASS}
            >
              <LifeBuoy className="h-[18px] w-[18px] shrink-0 text-subtle" aria-hidden />
              <span>Yordam</span>
            </button>
          </div>
        )}

        <button
          ref={triggerRef}
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-haspopup="menu"
          className={cn(
            'group flex w-full cursor-pointer items-center gap-3 rounded-2xl p-2 text-left transition',
            open ? 'bg-raised ring-1 ring-line-strong' : 'hover:bg-hover'
          )}
        >
          <Avatar name={userName} />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-semibold text-fg">{userName}</span>
            <span className="block truncate text-xs text-subtle">Mahalliy hisob</span>
          </span>
          <MoreHorizontal className="h-4 w-4 shrink-0 text-subtle transition group-hover:text-fg" aria-hidden />
        </button>
      </div>

      <Dialog
        open={profileOpen}
        onClose={() => setProfileOpen(false)}
        title="Profil"
        description="Koʻrinadigan ismingizni oʻzgartiring."
      >
        <div className="mt-4 space-y-4">
          <div className="flex items-center gap-3 rounded-2xl border border-line bg-panel p-3.5">
            <Avatar name={userName} size="lg" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-base font-semibold text-fg">{userName}</p>
              <p className="mt-0.5 flex items-center gap-1.5 text-xs text-subtle">
                <User className="h-3.5 w-3.5 shrink-0" aria-hidden />
                Mahalliy hisob — maʼlumotlar shu qurilmada saqlanadi
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveName} className="space-y-3">
            <div>
              <label htmlFor="user-name-input" className="block text-xs font-medium text-subtle">
                Koʻrinadigan ism
              </label>
              <input
                id="user-name-input"
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                maxLength={50}
                className="mt-1.5 w-full rounded-xl border border-line bg-canvas px-3 py-2 text-sm text-fg outline-none transition focus:border-accent"
              />
            </div>
            <div className="flex items-center justify-between gap-3 pt-1">
              <span role="status" className={cn('flex items-center gap-1.5 text-xs', nameSaved ? 'text-ok' : 'text-subtle')}>
                {nameSaved ? (
                  <>
                    <Check className="h-3.5 w-3.5" aria-hidden />
                    Saqlandi
                  </>
                ) : (
                  'Yon panelda koʻrsatiladi'
                )}
              </span>
              <button
                type="submit"
                disabled={!editName.trim()}
                className="cursor-pointer rounded-xl bg-accent px-4 py-2 text-xs font-semibold text-accent-fg transition hover:bg-accent-strong disabled:cursor-not-allowed disabled:opacity-40"
              >
                Saqlash
              </button>
            </div>
          </form>
        </div>
      </Dialog>

      <Dialog
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        title="Yordam"
        description="Core AI dan qulay foydalanish boʻyicha qisqa yoʻriqnoma."
      >
        <div className="mt-4 space-y-3.5 text-xs leading-relaxed text-muted">
          <div className="rounded-2xl border border-line bg-panel p-3.5">
            <h4 className="font-semibold text-fg">Tezkor tugmalar</h4>
            <dl className="mt-2.5 space-y-1.5">
              {SHORTCUTS.map(([label, keys]) => (
                <div key={label} className="flex items-center justify-between gap-3">
                  <dt>{label}</dt>
                  <dd>
                    <kbd className="rounded border border-line bg-canvas px-2 py-0.5 font-mono text-[11px] text-fg">{keys}</kbd>
                  </dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="rounded-2xl border border-line bg-panel p-3.5">
            <h4 className="font-semibold text-fg">Imkoniyatlar</h4>
            <ul className="mt-2 list-disc space-y-1.5 pl-4 marker:text-subtle">
              <li>Ovoz chiqarib oʻqish: javob ostidagi karnay belgisini bosing.</li>
              <li>Fayllar: rasm, PDF yoki matn/kod faylini biriktirib tahlil qildiring.</li>
              <li>Modelni almashtirish: Sozlamalar boʻlimidan.</li>
              <li>Suhbatlar tarixi faqat shu qurilmaning brauzer xotirasida saqlanadi.</li>
            </ul>
          </div>
        </div>
      </Dialog>
    </>
  );
}
