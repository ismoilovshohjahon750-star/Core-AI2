'use client';

import React, { memo, useState, type ReactNode } from 'react';
import ReactMarkdown, { type Components } from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Check, Copy } from 'lucide-react';

function nodeToText(node: ReactNode): string {
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(nodeToText).join('');
  if (React.isValidElement<{ children?: ReactNode }>(node)) return nodeToText(node.props.children);
  return '';
}

function CodeBlock({ code, language }: { code: string; language?: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // clipboard mavjud emas
    }
  };

  return (
    <div className="my-4 overflow-hidden rounded-2xl border border-code-line bg-code-bg">
      <div className="flex items-center justify-between border-b border-code-line px-4 py-1.5">
        <span className="font-mono text-xs text-[#8a96ad]">{language ?? 'matn'}</span>
        <button
          type="button"
          onClick={copy}
          className="flex cursor-pointer items-center gap-1.5 rounded-md px-2 py-1 text-xs text-[#aeb8cc] transition hover:bg-white/10 hover:text-white"
          aria-label="Kodni nusxalash"
        >
          {copied ? <Check className="h-3.5 w-3.5 text-ok" aria-hidden /> : <Copy className="h-3.5 w-3.5" aria-hidden />}
          <span aria-live="polite">{copied ? 'Nusxalandi' : 'Nusxalash'}</span>
        </button>
      </div>
      <pre className="overflow-x-auto p-4 font-mono text-[13px] leading-relaxed text-code-fg">
        <code>{code}</code>
      </pre>
    </div>
  );
}

const components: Components = {
  pre({ children }) {
    const child = React.Children.toArray(children)[0];
    const props = React.isValidElement<{ className?: string; children?: ReactNode }>(child) ? child.props : undefined;
    const language = /language-([\w+-]+)/.exec(props?.className ?? '')?.[1];
    const code = nodeToText(props?.children).replace(/\n$/, '');
    return <CodeBlock code={code} language={language} />;
  },
  code({ children }) {
    return (
      <code className="rounded-md bg-accent-soft px-1.5 py-0.5 font-mono text-[0.86em] text-fg">{children}</code>
    );
  },
  p: ({ children }) => <p className="my-3">{children}</p>,
  ul: ({ children }) => <ul className="my-3 list-disc space-y-1.5 pl-6 marker:text-subtle">{children}</ul>,
  ol: ({ children }) => <ol className="my-3 list-decimal space-y-1.5 pl-6 marker:text-subtle">{children}</ol>,
  li: ({ children }) => <li className="pl-1">{children}</li>,
  strong: ({ children }) => <strong className="font-semibold text-fg">{children}</strong>,
  h1: ({ children }) => <h1 className="mb-2 mt-6 text-xl font-semibold tracking-tight">{children}</h1>,
  h2: ({ children }) => <h2 className="mb-2 mt-5 text-lg font-semibold tracking-tight">{children}</h2>,
  h3: ({ children }) => <h3 className="mb-1.5 mt-4 text-base font-semibold">{children}</h3>,
  h4: ({ children }) => <h4 className="mb-1 mt-3 text-[15px] font-semibold">{children}</h4>,
  hr: () => <hr className="my-5 border-line" />,
  a: ({ href, children }) => (
    <a href={href} target="_blank" rel="noopener noreferrer">
      {children}
    </a>
  ),
  blockquote: ({ children }) => (
    <blockquote className="my-4 border-l-2 border-accent/60 pl-4 text-muted">{children}</blockquote>
  ),
  table: ({ children }) => (
    <div className="my-4 overflow-x-auto rounded-xl border border-line">
      <table className="w-full border-collapse text-left text-sm">{children}</table>
    </div>
  ),
  thead: ({ children }) => <thead className="bg-panel text-fg">{children}</thead>,
  tbody: ({ children }) => <tbody className="divide-y divide-line">{children}</tbody>,
  th: ({ children }) => <th className="whitespace-nowrap px-3.5 py-2.5 font-semibold">{children}</th>,
  td: ({ children }) => <td className="px-3.5 py-2.5 align-top">{children}</td>,
};

const remarkPlugins = [remarkGfm];

export const MarkdownRenderer = memo(function MarkdownRenderer({ content }: { content: string }) {
  return (
    <div className="md break-words text-[15.5px] leading-[1.75] text-fg">
      <ReactMarkdown remarkPlugins={remarkPlugins} components={components}>
        {content}
      </ReactMarkdown>
    </div>
  );
});
