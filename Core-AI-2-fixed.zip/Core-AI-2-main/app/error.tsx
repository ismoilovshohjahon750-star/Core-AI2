'use client';

export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="flex h-dvh flex-col items-center justify-center gap-5 bg-canvas px-6 text-center text-fg">
      <div className="space-y-2">
        <h1 className="text-xl font-semibold">Xatolik yuz berdi</h1>
        <p className="max-w-sm text-sm leading-relaxed text-muted">
          Kutilmagan nosozlik yuz berdi. Suhbatlaringiz brauzerda saqlangan — qayta urinib koʻring.
        </p>
      </div>
      <button
        type="button"
        onClick={() => reset()}
        className="cursor-pointer rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-accent-fg transition hover:bg-accent-strong"
      >
        Qayta urinish
      </button>
    </main>
  );
}
