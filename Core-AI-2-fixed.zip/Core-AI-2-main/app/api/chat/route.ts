import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';
import { stripEmojis } from '@/lib/chat-utils';
import { isValidModelId, DEFAULT_MODEL_ID } from '@/lib/model-config';
import { toOpenRouterMessages } from '@/lib/openrouter';
import {
  buildSystemInstruction,
  describeGeminiError,
  toGeminiContents,
  type IncomingMessage,
} from '@/lib/gemini';

export const runtime = 'nodejs';
export const maxDuration = 60;

const MAX_BODY_BYTES = 40 * 1024 * 1024;

/** .env.example dagi toʻldirilmagan namunaviy qiymatlarni haqiqiy qiymat deb hisoblamaymiz. */
function envValue(name: string, placeholder?: string): string | undefined {
  const value = process.env[name]?.trim();
  if (!value || value === placeholder) return undefined;
  return value;
}

function jsonError(message: string, status: number) {
  return NextResponse.json({ error: message }, { status, headers: { 'Cache-Control': 'no-store' } });
}

export async function POST(req: NextRequest) {
  const declaredLength = Number(req.headers.get('content-length') ?? 0);
  if (declaredLength > MAX_BODY_BYTES) {
    return jsonError('Yuborilgan maʼlumot hajmi juda katta. Fayllarni kamaytiring.', 413);
  }

  let body: { messages?: IncomingMessage[]; model?: string };
  try {
    body = await req.json();
  } catch {
    return jsonError("So'rov formati noto'g'ri.", 400);
  }

  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    return jsonError('Savol matni yoki biriktirilgan fayl kiritilmadi.', 400);
  }

  // Foydalanuvchi sozlamalarda tanlagan model ustun; GEMINI_MODEL faqat tanlov boʻlmaganda standart sifatida ishlaydi.
  const requestedModel = isValidModelId(body.model)
    ? body.model
    : envValue('GEMINI_MODEL') ?? DEFAULT_MODEL_ID;
  const isOpenRouterModel = requestedModel.includes('/');

  // 1. OpenRouter model boʻlsa
  if (isOpenRouterModel) {
    const openrouterApiKey = envValue('OPENROUTER_API_KEY');
    if (!openrouterApiKey) {
      return jsonError(
        'OPENROUTER_API_KEY sozlanmagan. .env.local faylida OPENROUTER_API_KEY=... kalitini sozlang yoki Gemini modellaridan birini tanlang.',
        503
      );
    }

    const openAiMessages = toOpenRouterMessages(body.messages, buildSystemInstruction());
    if (openAiMessages.length < 2) {
      return jsonError('Savol matni yoki biriktirilgan fayl kiritilmadi.', 400);
    }

    try {
      const openRouterRes = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openrouterApiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': envValue('APP_URL', 'MY_APP_URL') ?? 'http://localhost:3000',
          'X-Title': 'Core AI',
        },
        body: JSON.stringify({
          model: requestedModel,
          messages: openAiMessages,
          stream: true,
          temperature: 0.6,
        }),
        signal: req.signal,
      });

      if (!openRouterRes.ok || !openRouterRes.body) {
        let errText = 'OpenRouter xatosi yuz berdi.';
        try {
          const errData = await openRouterRes.json();
          if (errData?.error?.message) errText = errData.error.message;
        } catch {
          // ignore
        }
        return jsonError(`OpenRouter xatosi: ${errText}`, openRouterRes.status || 500);
      }

      const encoder = new TextEncoder();
      const reader = openRouterRes.body.getReader();

      const readable = new ReadableStream<Uint8Array>({
        async start(controller) {
          const decoder = new TextDecoder();
          let buffer = '';

          try {
            for (;;) {
              const { done, value } = await reader.read();
              if (done) break;

              buffer += decoder.decode(value, { stream: true });
              const lines = buffer.split('\n');
              buffer = lines.pop() ?? '';

              for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith(':')) continue;
                if (trimmed === 'data: [DONE]') continue;

                if (trimmed.startsWith('data: ')) {
                  try {
                    const json = JSON.parse(trimmed.slice(6));
                    const delta = json?.choices?.[0]?.delta?.content ?? '';
                    const text = stripEmojis(delta);
                    if (text) {
                      controller.enqueue(encoder.encode(text));
                    }
                  } catch {
                    // ignore JSON parse chunk errors
                  }
                }
              }
            }
            controller.close();
          } catch (err) {
            if (req.signal.aborted) {
              controller.close();
            } else {
              controller.error(err);
            }
          }
        },
        cancel() {
          void reader.cancel();
        },
      });

      return new Response(readable, {
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          'Cache-Control': 'no-store, no-transform',
          'X-Accel-Buffering': 'no',
        },
      });
    } catch (error) {
      console.error('[chat] OpenRouter error:', error);
      return jsonError('OpenRouter serveriga ulanishda xatolik yuz berdi.', 500);
    }
  }

  // 2. Standard Gemini Model boʻlsa
  const contents = toGeminiContents(body.messages);
  if (contents.length === 0) {
    return jsonError('Savol matni yoki biriktirilgan fayl kiritilmadi.', 400);
  }

  const apiKey = envValue('GEMINI_API_KEY', 'MY_GEMINI_API_KEY');
  if (!apiKey) {
    return jsonError(
      'GEMINI_API_KEY sozlanmagan. Loyiha papkasida .env.local faylini yarating, unga GEMINI_API_KEY=... qatorini qoʻshing va serverni qayta ishga tushiring.',
      503
    );
  }

  const ai = new GoogleGenAI({ apiKey });
  const model = requestedModel;

  try {
    const stream = await ai.models.generateContentStream({
      model,
      contents,
      config: {
        systemInstruction: buildSystemInstruction(),
        temperature: 0.6,
        abortSignal: req.signal,
      },
    });

    const encoder = new TextEncoder();
    const iterator = stream[Symbol.asyncIterator]();

    let first: IteratorResult<{ text?: string }>;
    try {
      first = await iterator.next();
    } catch (error) {
      console.error('[chat] Gemini xatosi:', error);
      const { status, message } = describeGeminiError(error);
      return jsonError(message, status);
    }

    const readable = new ReadableStream<Uint8Array>({
      async start(controller) {
        try {
          let current = first;
          let produced = false;
          while (!current.done) {
            const text = stripEmojis(current.value.text ?? '');
            if (text) {
              produced = true;
              controller.enqueue(encoder.encode(text));
            }
            current = await iterator.next();
          }
          if (!produced) {
            controller.enqueue(encoder.encode('Model boʻsh javob qaytardi. Savolni boshqacha ifodalab qayta urinib koʻring.'));
          }
          controller.close();
        } catch (error) {
          if (req.signal.aborted) {
            controller.close();
          } else {
            console.error('[chat] Oqim xatosi:', error);
            controller.error(error);
          }
        }
      },
      cancel() {
        void iterator.return?.(undefined as unknown as IteratorResult<{ text?: string }>);
      },
    });

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-store, no-transform',
        'X-Accel-Buffering': 'no',
      },
    });
  } catch (error) {
    console.error('[chat] Gemini xatosi:', error);
    const { status, message } = describeGeminiError(error);
    return jsonError(message, status);
  }
}
