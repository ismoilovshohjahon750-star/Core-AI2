import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';
import { cleanTextForSpeech } from '@/lib/speech-utils';
import { toPlayableAudio } from '@/lib/audio-utils';

export const runtime = 'nodejs';
export const maxDuration = 60;

/** gemini-3.8-flash-lite-tts — Gemini API hujjatlaridagi joriy tezkor TTS modeli (101 til). */
const DEFAULT_TTS_MODEL = 'gemini-3.8-flash-lite-tts';
const MAX_SPEECH_CHARS = 8000;

function configured(value: string | undefined, placeholder?: string): string | undefined {
  const v = value?.trim();
  return !v || v === placeholder ? undefined : v;
}

export async function POST(req: NextRequest) {
  let body: { text?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Notoʻgʻri format' }, { status: 400 });
  }

  const cleaned = cleanTextForSpeech(typeof body.text === 'string' ? body.text : '');
  if (!cleaned) {
    return NextResponse.json({ error: 'Ovozga aylantirish uchun matn topilmadi' }, { status: 400 });
  }
  const speechText = cleaned.slice(0, MAX_SPEECH_CHARS);

  const apiKey = configured(process.env.GEMINI_API_KEY, 'MY_GEMINI_API_KEY');
  if (!apiKey) {
    return NextResponse.json({ error: 'GEMINI_API_KEY sozlanmagan' }, { status: 503 });
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: configured(process.env.GEMINI_TTS_MODEL) ?? DEFAULT_TTS_MODEL,
      contents: [{ role: 'user', parts: [{ text: speechText }] }],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
        },
        abortSignal: req.signal,
      },
    });

    const inline = response.candidates?.[0]?.content?.parts?.find((p) => p.inlineData?.data)?.inlineData;
    if (!inline?.data) {
      return NextResponse.json({ error: 'Ovoz maʼlumoti olinmadi' }, { status: 502 });
    }

    // Gemini TTS xom PCM qaytaradi — brauzer oʻynay olishi uchun WAV sarlavhasi qoʻshiladi.
    const { bytes, contentType } = toPlayableAudio(inline.data, inline.mimeType);
    return new Response(Buffer.from(bytes), {
      headers: {
        'Content-Type': contentType,
        'Content-Length': String(bytes.byteLength),
        'Cache-Control': 'private, no-store',
      },
    });
  } catch (err: unknown) {
    if (req.signal.aborted) return new Response(null, { status: 499 });
    console.error('[tts] Server ovoz xatosi:', err);
    return NextResponse.json({ error: 'Server ovoz xizmatida xatolik' }, { status: 500 });
  }
}
