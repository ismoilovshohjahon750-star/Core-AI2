'use client';

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="uz">
      <body
        style={{
          margin: 0,
          minHeight: '100dvh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 16,
          padding: 24,
          textAlign: 'center',
          background: '#0b0f17',
          color: '#e8ecf4',
          fontFamily: 'system-ui, sans-serif',
        }}
      >
        <h1 style={{ fontSize: 22, margin: 0 }}>Tizim xatoligi</h1>
        <p style={{ margin: 0, color: '#9aa6bc', maxWidth: 360, lineHeight: 1.6, fontSize: 14 }}>
          Kutilmagan xatolik yuz berdi. Sahifani qayta yuklab koʻring.
        </p>
        <button
          type="button"
          onClick={() => reset()}
          style={{
            cursor: 'pointer',
            border: 0,
            borderRadius: 12,
            padding: '10px 20px',
            fontWeight: 600,
            background: '#8499ff',
            color: '#0b0f17',
          }}
        >
          Qayta yuklash
        </button>
      </body>
    </html>
  );
}
